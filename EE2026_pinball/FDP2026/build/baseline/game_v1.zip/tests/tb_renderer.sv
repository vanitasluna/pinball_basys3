`timescale 1ns/1ps
module tb_renderer;
    reg [6:0] x=0,ball_x=39,cursor_x=76;
    reg [5:0] y=0,ball_y=43,charge=45,cursor_y=50;
    reg [2:0] state=0,left_angle=4,right_angle=0;
    reg [15:0] score_bcd=16'h1250,high_bcd=16'h3450;
    reg [1:0] lives=3,difficulty=1,bonus_target=1;
    reg [4:0] hit_flash=1;
    reg bonus_active=1,cursor_visible=0;
    reg [7:0] anim=32;
    reg [2:0] combo=3,mission_progress=3'b101,feature_event=3;
    reg [1:0] target_progress=2'b01;
    reg [10:0] save_timer=600;
    reg [9:0] feature_timer=0;
    reg [15:0] last_award_bcd=16'h0500;
    reg [55:0] oled_trail_x=0;
    reg [47:0] oled_trail_y=0;
    reg [7:0] trail_valid=8'h03;
    wire [15:0] pixel;
    pinball_renderer dut(.*);
    integer s,xx,yy,f;
    reg [8*80-1:0] path;
    task expect_pixel;
        input [6:0] px;
        input [5:0] py;
        input [15:0] expected;
        begin
            x=px; y=py; #1;
            if(pixel!==expected)
                $fatal(1,"Pixel x=%0d y=%0d got=%04h expected=%04h",px,py,pixel,expected);
        end
    endtask
    initial begin
        oled_trail_x[0+:7]=31; oled_trail_y[0+:6]=41;
        oled_trail_x[7+:7]=33; oled_trail_y[6+:6]=42;
        state=2;
        expect_pixel(33,1,16'hFEA0); // Visible X3 combo glyph.
        expect_pixel(75,1,16'h07FF); // Active ball-save S glyph.
        expect_pixel(26,16,16'hFEA0); // Completed upper-left mission lamp.
        expect_pixel(58,16,16'h4A8A); // Upper-right mission remains incomplete.
        expect_pixel(10,30,16'hFEA0); // Completed left side target.
        expect_pixel(74,30,16'h4A8A); // Right side target remains incomplete.
        expect_pixel(31,41,16'h7BF0); // Recent ball history is drawn.
        trail_valid=0;
        expect_pixel(31,41,16'h10E7); // Invalid trail sample disappears.
        trail_valid=8'h03;
        expect_pixel(39,43,16'hEF7D); // Glossy ball center stays distinct.
        expect_pixel(31,24,16'hFFFF); // First expanding impact-ring phase.
        anim=36;
        expect_pixel(31,24,16'h08A5); // Ring vacates its old location.
        expect_pixel(32,24,16'hFEA0); // Next phase expands and changes color.
        anim=32; feature_timer=100;
        expect_pixel(22,12,16'hFEA0); // JACKPOT toast appears.
        feature_timer=0;
        expect_pixel(22,12,16'h10E7); // Toast expires without hiding the table.
        for(s=0;s<6;s=s+1) begin
            state=s==5 ? 2 : s;
            feature_timer=s==5 ? 100 : 0;
            $sformat(path,"../render_%0d.hex",s);
            f=$fopen(path,"w");
            if(!f)$fatal(1,"Cannot open render output");
            for(yy=0;yy<64;yy=yy+1) for(xx=0;xx<96;xx=xx+1) begin
                x=xx;y=yy;#1;
                if(^pixel===1'bx)$fatal(1,"Unknown pixel state=%0d x=%0d y=%0d",s,xx,yy);
                $fdisplay(f,"%04x",pixel);
            end
            $fclose(f);
        end
        $display("PASS tb_renderer: visual feature checks and six complete RGB565 frames contain no unknown pixels");
        $finish;
    end
endmodule

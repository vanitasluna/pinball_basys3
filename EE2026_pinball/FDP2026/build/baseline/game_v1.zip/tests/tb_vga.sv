`timescale 1ns/1ps
module tb_vga;
    reg clk=0, reset=1;
    wire [6:0] x;
    wire [5:0] y;
    wire frame_begin;
    wire [3:0] red,green,blue;
    wire hsync,vsync;
    // Position-dependent colors detect incorrect scaling as well as bit slicing.
    wire [15:0] pixel={x[4:0],y[5:0],(x[4:0]^y[4:0])};
    integer expected_h,expected_v,hs_low,vs_low,image_pixels,frames;
    integer lx,ly;
    reg [15:0] expected_pixel;
    reg expected_hs,expected_vs,expected_inside;
    always #20 clk=~clk;
    pinball_vga dut(.clk(clk),.reset(reset),.pixel(pixel),.x(x),.y(y),
        .frame_begin(frame_begin),.red(red),.green(green),.blue(blue),
        .hsync(hsync),.vsync(vsync));

    initial begin
        repeat(3) @(posedge clk);
        @(negedge clk); reset=0;
        expected_h=0; expected_v=0; hs_low=0; vs_low=0; image_pixels=0; frames=0;
        repeat(800*525) begin
            // The renderer sees the current coordinate before the output register.
            #1;
            expected_inside=expected_h>=32 && expected_h<608 && expected_v>=48 && expected_v<432;
            lx=expected_inside ? (expected_h-32)/6 : 0;
            ly=expected_inside ? (expected_v-48)/6 : 0;
            if(x!==lx || y!==ly) $fatal(1,"Sixfold image coordinate wrong at (%0d,%0d): %0d,%0d",expected_h,expected_v,x,y);
            if(frame_begin) frames=frames+1;
            if(frame_begin !== (expected_h==0 && expected_v==0)) $fatal(1,"Frame boundary incorrect");
            expected_pixel=pixel;
            expected_hs=!(expected_h>=656 && expected_h<752);
            expected_vs=!(expected_v>=490 && expected_v<492);
            @(posedge clk); #1;
            if($isunknown({x,y,red,green,blue,hsync,vsync,frame_begin})) $fatal(1,"Unknown VGA output");
            if(hsync!==expected_hs || vsync!==expected_vs) $fatal(1,"Sync timing wrong at (%0d,%0d)",expected_h,expected_v);
            if(expected_inside) begin
                image_pixels=image_pixels+1;
                if({red,green,blue}!=={expected_pixel[15:12],expected_pixel[10:7],expected_pixel[4:1]})
                    $fatal(1,"RGB565 conversion incorrect at (%0d,%0d)",expected_h,expected_v);
            end else if({red,green,blue}!==12'd0) $fatal(1,"Blanking/border is not black");
            if(!hsync) hs_low=hs_low+1;
            if(!vsync) vs_low=vs_low+1;
            if(expected_h==799) begin expected_h=0; expected_v=expected_v==524 ? 0 : expected_v+1; end
            else expected_h=expected_h+1;
            @(negedge clk);
        end
        if(frames!=1 || !frame_begin) $fatal(1,"Frame period is not 420000 clocks");
        if(hs_low!=96*525 || vs_low!=2*800) $fatal(1,"Sync pulse widths incorrect");
        if(image_pixels!=96*64*36) $fatal(1,"Image does not cover exactly sixfold OLED pixels");
        $display("PASS tb_vga: 800x525 frame, sync widths, centered 6x OLED image, RGB565 conversion and black borders");
        $finish;
    end
    initial begin #20000000; $fatal(1,"tb_vga timeout"); end
endmodule

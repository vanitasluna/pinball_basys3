`timescale 1ns/1ps
module tb_collision;
    reg signed [15:0] proposed_x, proposed_y, velocity_x, velocity_y;
    reg signed [15:0] previous_x, previous_y;
    reg in_lane, left_pressed, right_pressed, left_moving, right_moving;
    reg [2:0] left_angle, right_angle;
    wire signed [15:0] corrected_x, corrected_y, corrected_vx, corrected_vy;
    wire [4:0] hit_events;
    integer checks = 0;

    pinball_collision dut (.*);

    task setup;
        input integer x, y, vx, vy;
        begin
            proposed_x = x; proposed_y = y;
            previous_x = x; previous_y = y - vy;
            velocity_x = vx; velocity_y = vy;
            in_lane = 0; left_angle = 0; right_angle = 0;
            left_pressed = 0; right_pressed = 0;
            left_moving = 0; right_moving = 0;
        end
    endtask

    task check;
        input condition;
        input [511:0] message;
        begin
            checks = checks + 1;
            if (!condition) begin
                $display("FAIL collision: %0s x=%0d y=%0d vx=%0d vy=%0d hits=%b",
                    message, corrected_x, corrected_y, corrected_vx, corrected_vy, hit_events);
                $fatal(1);
                $finish;
            end
        end
    endtask

    initial begin
        setup(2*256, 15*256, -200, 0); #1;
        check(corrected_x == 4*256 && corrected_vx == 175, "left wall restitution");
        setup(2*256, 15*256, 200, 0); #1;
        check(corrected_x == 4*256 && corrected_vx == 200, "outgoing wall velocity retained");
        setup(20*256, 9*256, 0, -200); #1;
        check(corrected_y == 11*256 && corrected_vy == 175, "top wall correction");
        setup(86*256, 20*256, 200, 0); #1;
        check(corrected_x == 82*256 && corrected_vx == -175, "divider prevents lane reentry");
        setup(89*256, 20*256, 0, -200); in_lane = 1; #1;
        check(corrected_x == 89*256 && corrected_y == 20*256, "shooter lane permitted");

        setup(26*256, 16*256, 0, 256); #1;
        check(hit_events == 5'b00001 && corrected_vy < 0 && corrected_y < 16*256,
            "left bumper bit and outward correction");
        setup(58*256, 16*256, 0, 256); #1;
        check(hit_events == 5'b00010 && corrected_vy < 0, "right bumper bit");
        setup(42*256, 29*256, 0, 256); #1;
        check(hit_events == 5'b00100 && corrected_vy < 0, "centre bumper bit");
        setup(26*256, 16*256, 0, -256); #1;
        check(hit_events == 0 && corrected_vy == -256, "outgoing bumper does not retrigger");
        setup(30*256, 26*256, -160, -160); #1;
        check(hit_events == 5'b00001 && corrected_vx > 0 && corrected_vy > 0,
            "diagonal bumper reflection");
        setup(9*256, 33*256, -200, 0); #1;
        check(hit_events == 5'b01000 && corrected_vx > 0 && corrected_x > 10*256,
            "left target bit");
        setup(76*256, 33*256, 200, 0); #1;
        check(hit_events == 5'b10000 && corrected_vx < 0 && corrected_x < 75*256,
            "right target bit");

        setup(30*256, 54*256, 0, 256); previous_y = 52*256; #1;
        check(corrected_vy < 0 && corrected_vx > 0 && corrected_y < proposed_y,
            "resting left flipper returns falling ball towards gap");
        setup(56*256, 54*256, 0, 256); previous_y = 52*256; #1;
        check(corrected_vy < 0 && corrected_vx < 0, "right flipper mirrored return");
        setup(36*256, 48*256+128, 0, 50);
        previous_y = 48*256; left_angle = 4; left_pressed = 1; left_moving = 1; #1;
        check(corrected_vy <= -300 && corrected_vx > 0, "moving flipper strong impulse");
        setup(30*256, 49*256, 0, 100);
        previous_y = 47*256; left_angle = 4; left_pressed = 1; #1;
        check(corrected_vy < -176 && corrected_vy > -260, "held flipper weaker impulse");
        setup(30*256, 54*256, 0, 100);
        previous_y = 54*256; left_angle = 4; #1;
        check(corrected_y == proposed_y && corrected_vy == 100,
            "ball below raised flipper is not teleported");
        setup(10*256, 46*256, 0, 200); #1;
        check(corrected_vx > 0 && corrected_vy < 0, "left guide directs inward");
        $display("PASS tb_collision (%0d checks)", checks);
        $finish;
    end
endmodule

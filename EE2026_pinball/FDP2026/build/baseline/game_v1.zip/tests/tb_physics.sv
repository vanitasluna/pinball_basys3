`timescale 1ns/1ps
module tb_physics;
    reg clk = 0;
    always #5 clk = !clk;
    reg reset = 1, tick = 0, active = 1, prepare = 0, launch = 0;
    reg [5:0] launch_power = 16;
    reg [1:0] difficulty = 0;
    reg left_pressed = 0, right_pressed = 0;
    wire [6:0] ball_x;
    wire [5:0] ball_y;
    wire [2:0] left_angle, right_angle;
    wire drained, in_lane;
    wire [4:0] hit_events;
    integer checks = 0, d, p, n;
    reg saw_drain;
    reg signed [15:0] saved_x, saved_y, saved_vx, saved_vy;
    reg [2:0] saved_angle;
    pinball_physics dut (.*);

    task check;
        input condition;
        input [511:0] message;
        begin
            checks = checks + 1;
            if (!condition) begin
                $display("FAIL physics: %0s d=%0d p=%0d n=%0d x=%0d y=%0d vx=%0d vy=%0d",
                    message, difficulty, launch_power, n,
                    dut.position_x, dut.position_y, dut.velocity_x, dut.velocity_y);
                $fatal(1);
                $finish;
            end
        end
    endtask

    task step;
        begin
            @(negedge clk); tick = 1;
            @(negedge clk); tick = 0;
            repeat (16) @(negedge clk);
            check(dut.velocity_x <= 384 && dut.velocity_x >= -384 &&
                  dut.velocity_y <= 384 && dut.velocity_y >= -384, "velocity cap");
            check(ball_x <= 95 && ball_y <= 63, "OLED coordinates bounded");
        end
    endtask

    task prepare_ball;
        begin
            @(negedge clk); prepare = 1; launch = 0;
            @(negedge clk); prepare = 0;
            check(ball_x == 89 && ball_y == 56 && in_lane && !dut.launched,
                  "prepare restores stationary shooter ball");
        end
    endtask

    task shoot;
        begin
            // Tick remains low for the entire launch pulse.
            @(negedge clk); launch = 1;
            @(negedge clk); launch = 0;
            check(dut.launched && dut.velocity_y < 0, "launch captured independently of tick");
        end
    endtask

    initial begin
        repeat (3) @(negedge clk);
        reset = 0;
        for (d = 0; d < 3; d = d + 1) begin
            difficulty = d;
            for (p = 0; p < 2; p = p + 1) begin
                launch_power = p ? 63 : 16;
                prepare_ball;
                shoot;
                n = 0;
                while (in_lane && n < 200) begin step; n = n + 1; end
                check(!in_lane, "light/full shots leave lane on all difficulties");
                saw_drain = 0;
                n = 0;
                while (!saw_drain && n < 7200) begin
                    step; n = n + 1;
                    if (drained) saw_drain = 1;
                    check(!in_lane, "launched ball never reenters shooter lane");
                end
                check(saw_drain, "uncontrolled shot eventually drains");
                step;
                check(!drained && !dut.launched, "drain is a one-cycle pulse and freezes ball");
            end
        end

        difficulty = 0; launch_power = 16;
        prepare_ball; shoot;
        repeat (10) step;
        saved_x = dut.position_x; saved_y = dut.position_y;
        saved_vx = dut.velocity_x; saved_vy = dut.velocity_y; saved_angle = left_angle;
        active = 0; left_pressed = 1;
        repeat (20) step;
        check(dut.position_x == saved_x && dut.position_y == saved_y &&
              dut.velocity_x == saved_vx && dut.velocity_y == saved_vy &&
              left_angle == saved_angle, "pause freezes ball and flipper state");
        active = 1;
        repeat (4) step;
        check(left_angle == 4, "flipper reaches raised angle in four ticks");
        left_pressed = 0;
        repeat (4) step;
        check(left_angle == 0, "flipper returns in four ticks");

        // Controlled geometric contact verifies score rearm, independently
        // of the repeatable launcher trajectory used above.
        prepare_ball; shoot;
        @(negedge clk);
        dut.in_lane = 0;
        dut.position_x = 26*256; dut.position_y = 15*256;
        dut.velocity_x = 0; dut.velocity_y = 300;
        step;
        check(hit_events == 5'b00001 && !dut.hit_armed[0], "bumper event disarms score");
        @(negedge clk);
        dut.position_x = 26*256; dut.position_y = 15*256;
        dut.velocity_x = 0; dut.velocity_y = 300;
        step;
        check(hit_events == 0, "same bumper contact cannot score during cooldown");
        @(negedge clk);
        dut.position_x = 70*256; dut.position_y = 12*256;
        dut.velocity_x = 0; dut.velocity_y = 0;
        repeat (20) step;
        check(dut.hit_armed[0], "score rearms after cooldown and leaving bumper");
        @(negedge clk);
        dut.position_x = 26*256; dut.position_y = 15*256;
        dut.velocity_x = 0; dut.velocity_y = 300;
        step;
        check(hit_events == 5'b00001, "new approach to rearmed bumper scores");

        difficulty = 0; left_pressed = 0;
        prepare_ball; shoot;
        saved_x = dut.position_x; saved_y = dut.position_y;
        @(negedge clk); tick = 1;
        @(negedge clk); tick = 0;
        check(dut.collision_busy && dut.collision_velocity_y == -303,
              "tick snapshots proposed motion before calculation window");
        difficulty = 2; left_pressed = 1;
        repeat (15) begin
            @(negedge clk);
            check(dut.position_x == saved_x && dut.position_y == saved_y &&
                  dut.collision_busy, "result does not commit before16 system clocks");
            check(dut.collision_velocity_y == -303 && !dut.collision_left_pressed,
                  "difficulty and buttons cannot change outstanding snapshot");
        end
        @(negedge clk);
        check(!dut.collision_busy && dut.position_y == saved_y - 303,
              "snapshot result commits on the16th clock");

        prepare_ball; shoot;
        @(negedge clk); tick = 1;
        @(negedge clk); tick = 0;
        check(dut.collision_busy, "calculation begins before cancellation");
        @(negedge clk); prepare = 1;
        @(negedge clk); prepare = 0;
        repeat (20) @(negedge clk);
        check(!dut.collision_busy && !dut.launched && ball_x == 89 && ball_y == 56,
              "prepare cancels outstanding calculation without stale commit");

        $display("PASS tb_physics (%0d checks)", checks);
        $finish;
    end
endmodule

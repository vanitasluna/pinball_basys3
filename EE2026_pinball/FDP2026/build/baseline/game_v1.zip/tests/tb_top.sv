`timescale 1ns/1ps
module tb_top;
    reg clk=0;
    reg btnC=0,btnU=0,btnL=0,btnR=0,btnD=0;
    reg [15:0] sw=0;
    wire [7:0] JA;
    tri1 PS2Clk,PS2Data; // Model the board's mandatory PS/2 pull-ups.
    wire [15:0] led;
    wire [6:0] seg;
    wire [3:0] an,vgaRed,vgaGreen,vgaBlue;
    wire dp,Hsync,Vsync;
    integer config_x=0,config_y=0,center_x=0,center_y=0;
    integer command_count=0,spi_bits=0,data_bits=0,sampled_pixels=0;
    reg [39:0] spi_packet=0,expected_command[0:24];
    integer expected_bits[0:24];
    reg [15:0] expected_pixel=0,first_pixel=0,first_serial_pixel=0;
    reg first_pixel_loaded=0;
    reg packet_left=0,packet_middle=0,packet_right=0,packet_event=0;
    reg [11:0] packet_x=48,packet_y=32;
    integer accepted_clicks=0;
    always #5 clk=~clk;
    My_Top_Module dut(.clk(clk),.btnC(btnC),.btnU(btnU),.btnL(btnL),.btnR(btnR),.btnD(btnD),
        .sw(sw),.JA(JA),.PS2Clk(PS2Clk),.PS2Data(PS2Data),.led(led),.seg(seg),.an(an),.dp(dp),
        .vgaRed(vgaRed),.vgaGreen(vgaGreen),.vgaBlue(vgaBlue),.Hsync(Hsync),.Vsync(Vsync));

    // Observe configuration requests at the exact edge sampled by MouseCtl.
    always @(posedge clk) if(!dut.reset) begin
        if(dut.mouse_click) accepted_clicks=accepted_clicks+1;
        case(dut.mouse_config)
            0: begin if(dut.mouse_value!==12'd95) $fatal(1,"Mouse X bound wrong"); config_x=config_x+1; end
            1: begin if(dut.mouse_value!==12'd63) $fatal(1,"Mouse Y bound wrong"); config_y=config_y+1; end
            2: begin if(dut.mouse_value!==12'd48) $fatal(1,"Mouse X centering wrong"); center_x=center_x+1; end
            3: begin if(dut.mouse_value!==12'd32) $fatal(1,"Mouse Y centering wrong"); center_y=center_y+1; end
        endcase
    end

    // Abstract a completed PS/2 packet at the protected controller's outputs.
    // Button bytes may precede new_event; game clicks must use whole packets.
    task complete_packet(input expected_click);
        @(negedge clk); packet_event=1;
        @(posedge clk); #2;
        if(dut.mouse_click!==expected_click) $fatal(1,"Completed mouse packet produced the wrong click edge");
        @(negedge clk); packet_event=0;
        @(posedge clk); #2;
        if(dut.mouse_click!==0) $fatal(1,"Mouse packet click lasted more than one cycle");
        if(dut.mouse_prev!=={packet_right,packet_middle,packet_left})
            $fatal(1,"Previous mouse buttons did not commit on delayed packet completion");
    endtask

    // Keep real SPI clocks and all initialization words. Skip only long waits.
    // This tests sequencing/sampling; physical power-up delays are a hardware check.
    initial begin
        wait(!dut.reset);
        forever begin
            @(negedge dut.oled_clk); #1;
            if(dut.oled.delay>100) begin
                force dut.oled.delay=0;
                #1; release dut.oled.delay;
            end
        end
    end

    always @(posedge JA[3]) if(JA[0]===1'b0) begin
        if(JA[4]===1'b0) begin
            spi_packet={spi_packet[38:0],JA[1]}; spi_bits=spi_bits+1;
        end else if(JA[4]===1'b1 && data_bits<16) begin
            first_serial_pixel={first_serial_pixel[14:0],JA[1]}; data_bits=data_bits+1;
            if(data_bits==16 && first_serial_pixel!==first_pixel)
                $fatal(1,"First serialized RGB565 pixel disagrees with renderer");
        end
    end
    always @(posedge JA[0]) if(spi_bits!=0) begin
        if(command_count>24) $fatal(1,"Unexpected OLED command before first pixel");
        if(spi_bits!=expected_bits[command_count] || spi_packet!==expected_command[command_count])
            $fatal(1,"OLED command %0d wrong: %0d bits %h",command_count,spi_bits,spi_packet);
        command_count=command_count+1; spi_bits=0; spi_packet=0;
    end
    always @(posedge dut.oled_clk) begin
        #1;
        if(dut.sample_pixel) expected_pixel=dut.oled_pixel;
    end
    always @(negedge dut.oled_clk) begin
        #2;
        if(dut.sending_pixels && dut.oled.spi_word_bit_count==16) begin
            if(dut.oled.spi_word[39:24]!==expected_pixel) $fatal(1,"OLED sampled stale/wrong pixel");
            if(!first_pixel_loaded) begin first_pixel=expected_pixel; first_pixel_loaded=1; end
            sampled_pixels=sampled_pixels+1;
        end
    end

    initial begin
        expected_command[0]=40'hFD12; expected_bits[0]=16;
        expected_command[1]=40'hAE; expected_bits[1]=8;
        expected_command[2]=40'hA072; expected_bits[2]=16;
        expected_command[3]=40'hA100; expected_bits[3]=16;
        expected_command[4]=40'hA200; expected_bits[4]=16;
        expected_command[5]=40'hA4; expected_bits[5]=8;
        expected_command[6]=40'hA83F; expected_bits[6]=16;
        expected_command[7]=40'hAD8E; expected_bits[7]=16;
        expected_command[8]=40'hB00B; expected_bits[8]=16;
        expected_command[9]=40'hB131; expected_bits[9]=16;
        expected_command[10]=40'hB3F0; expected_bits[10]=16;
        expected_command[11]=40'h8A64; expected_bits[11]=16;
        expected_command[12]=40'h8B78; expected_bits[12]=16;
        expected_command[13]=40'h8C64; expected_bits[13]=16;
        expected_command[14]=40'hBB3A; expected_bits[14]=16;
        expected_command[15]=40'hBE3E; expected_bits[15]=16;
        expected_command[16]=40'h8706; expected_bits[16]=16;
        expected_command[17]=40'h8191; expected_bits[17]=16;
        expected_command[18]=40'h8250; expected_bits[18]=16;
        expected_command[19]=40'h837D; expected_bits[19]=16;
        expected_command[20]=40'h25; expected_bits[20]=8;
        expected_command[21]=40'h2500005F3F; expected_bits[21]=40;
        expected_command[22]=40'hAF; expected_bits[22]=8;
        expected_command[23]=40'h15005F; expected_bits[23]=24;
        expected_command[24]=40'h75003F; expected_bits[24]=24;
        repeat(24) @(posedge clk); #2;
        if(!dut.reset || JA[7]!==1'b0) $fatal(1,"Power-on reset did not hold OLED power off");
        repeat(56) @(posedge clk); #2;
        if(dut.reset || dut.mouse_config!=4) $fatal(1,"Power-on reset/configuration failed to complete");
        if(config_x!=1 || config_y!=1 || center_x!=1 || center_y!=1) $fatal(1,"Mouse configuration requests must each occur once");
        if(dut.mouse_x!==12'd48 || dut.mouse_y!==12'd32) $fatal(1,"Protected MouseCtl did not apply initial position");
        if(dut.mouse_seen || dut.mouse_click || dut.left_pressed || dut.right_pressed || dut.launch_down)
            $fatal(1,"Missing mouse injected a game action");
        if($isunknown({JA,led,seg,an,dp,Hsync,Vsync,vgaRed,vgaGreen,vgaBlue,dut.buttons,dut.state}))
            $fatal(1,"Unknown top-level display/control output after startup");
        if(JA[2]!==1'b0 || JA[7]!==1'b1) $fatal(1,"OLED connector mapping/power enable incorrect");

        wait(dut.oled.state==5'b10001);
        if(command_count!=25 || JA[4]!==0 || JA[5]!==1 || JA[6]!==1 || JA[7]!==1)
            $fatal(1,"OLED initialization/power/data-command sequencing failed");
        // Advance the idle frame boundary without changing the driver's source.
        @(negedge dut.oled_clk); #3;
        force dut.oled.frame_counter=0; #1; release dut.oled.frame_counter;
        wait(sampled_pixels>=8 && data_bits==16);
        if(command_count!=25 || JA[4]!==1) $fatal(1,"OLED did not enter RGB pixel streaming");
        if(dut.pixel_index<7 || dut.pixel_index>9) $fatal(1,"OLED raster indexing incorrect");
        sw[0]=1; repeat(8) @(posedge clk); #2;
        if(dut.mouse_click || dut.left_pressed || dut.right_pressed || dut.launch_down)
            $fatal(1,"Enabling an absent mouse injected actions");

        // A first click must work without an earlier movement packet. Model the
        // old Y output until the event edge, then supply the new Y in the cycle
        // before the game consumes its delayed packet. Old Y is the difficulty
        // row; new Y is a start row, exposing dispatch based on stale position.
        force dut.mouse_left=packet_left;
        force dut.mouse_middle=packet_middle;
        force dut.mouse_right=packet_right;
        force dut.mouse_event=packet_event;
        force dut.mouse_x=packet_x;
        force dut.mouse_y=packet_y;
        @(negedge clk); packet_left=1; packet_x=60; packet_y=35;
        repeat(4) @(posedge clk); #2;
        if(dut.mouse_click || dut.mouse_seen || dut.mouse_prev!==0 || dut.state!==0 || dut.difficulty!==1)
            $fatal(1,"Mouse byte 1 triggered a click before packet completion");
        @(negedge clk); packet_event=1;
        @(posedge clk); #2;
        if(!dut.mouse_click || !dut.mouse_seen || dut.mouse_prev!==0 || dut.state!==0)
            $fatal(1,"First complete mouse click was lost or consumed too early");
        packet_y=12; #1;
        if(dut.cursor_y!==12 || dut.mouse_level!==0)
            $fatal(1,"New mouse Y was not available for delayed packet dispatch");
        @(negedge clk); packet_event=0;
        @(posedge clk); #2;
        if(dut.state!==1 || dut.difficulty!==1 || accepted_clicks!=1 || dut.mouse_click)
            $fatal(1,"First mouse click used stale Y, repeated, or failed to start");

        // Repeated movement packets while held must never create another click.
        complete_packet(0); complete_packet(0);
        if(accepted_clicks!=1) $fatal(1,"Held mouse button repeated a click");
        @(negedge clk); packet_left=0;
        repeat(3) @(posedge clk); #2;
        if(dut.mouse_prev!==1) $fatal(1,"Raw release byte changed prior complete-packet state");
        complete_packet(0);
        if(dut.mouse_prev!==0 || accepted_clicks!=1) $fatal(1,"Release packet created a click");
        @(negedge clk); packet_left=1;
        repeat(3) @(posedge clk); #2;
        if(dut.mouse_click || accepted_clicks!=1) $fatal(1,"Raw press byte triggered a new click");
        complete_packet(1);
        if(accepted_clicks!=2) $fatal(1,"Release followed by press did not re-arm mouse click");
        release dut.mouse_left;
        release dut.mouse_middle;
        release dut.mouse_right;
        release dut.mouse_event;
        release dut.mouse_x;
        release dut.mouse_y;

        sw[15]=1; repeat(16) @(posedge clk); #2;
        if(!dut.reset || JA[7]!==0 || dut.state!==0) $fatal(1,"SW15 system reset failed");
        sw[15]=0; repeat(20) @(posedge clk); #2;
        if(dut.reset || dut.mouse_x!==48 || dut.mouse_y!==32) $fatal(1,"Reset release failed to reconfigure mouse");
        $display("PASS tb_top: reset, protected MouseCtl configuration, packet-complete mouse click edges/cursor dispatch, JA pinmap, OLED SPI and first pixels, absent-mouse fallback");
        $finish;
    end
    initial begin #2000000; $fatal(1,"tb_top timeout"); end
endmodule

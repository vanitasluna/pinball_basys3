`timescale 1ns/1ps
module tb_game;
    reg clk=0; always #5 clk=~clk;
    reg reset=1,tick=0,start_press=0,launch_down=0,pause_press=0,menu_press=0;
    reg level_left=0,level_right=0,drained=0;
    reg [4:0] hit_events=0;
    wire [2:0] state;
    wire [1:0] lives,difficulty,bonus_target;
    wire [15:0] score_bcd,high_bcd;
    wire [5:0] charge;
    wire prepare,launch,active,bonus_active;
    wire [4:0] hit_flash;
    wire [7:0] anim;
    reg [9:0] timer_before_pause;
    reg [1:0] late_bonus_target;
    pinball_game dut(.*);
    task cycle; @(posedge clk); #1; endtask
    task game_tick; @(negedge clk);tick=1;cycle();@(negedge clk);tick=0;cycle();endtask
    task start; @(negedge clk);start_press=1;cycle();
        if(!prepare || state!=1) $fatal(1,"Start did not prepare ball");
        @(negedge clk);start_press=0;cycle();endtask
    task shoot; @(negedge clk);launch_down=1;
        repeat(80) game_tick();
        @(negedge clk);launch_down=0;cycle();
        if(!launch || state!=2 || charge!=20) $fatal(1,"Charge or launch failed");
        cycle();if(launch) $fatal(1,"Launch pulse longer than one clock");endtask
    task lose_ball; @(negedge clk);drained=1;cycle();
        @(negedge clk);drained=0;cycle();endtask
    initial begin
        repeat(3)cycle();@(negedge clk);reset=0;cycle();
        if(state!=0 || difficulty!=1 || lives!=3) $fatal(1,"Reset failed");
        @(negedge clk);level_left=1;cycle();@(negedge clk);level_left=0;cycle();
        if(difficulty!=0) $fatal(1,"Level selection failed");
        start();
        // Releasing a partially charged ball while paused must not launch it
        // on resume. A subsequent hold/release starts a fresh charge.
        @(negedge clk);launch_down=1;repeat(24)game_tick();
        if(charge!=6) $fatal(1,"Ready charge setup failed");
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;launch_down=0;cycle();
        repeat(6)game_tick();
        if(state!=3 || launch || charge!=6) $fatal(1,"Ready pause did not freeze charge");
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;cycle();
        repeat(3)game_tick();
        if(state!=1 || launch || charge!=0) $fatal(1,"Resume launched a released ready ball");
        shoot();
        @(negedge clk);hit_events=1;cycle();@(negedge clk);hit_events=0;cycle();
        if(score_bcd!=16'h0050 || high_bcd!=16'h0050 || !hit_flash[0]) $fatal(1,"Bumper score failed");
        @(negedge clk);hit_events=8;cycle();@(negedge clk);hit_events=0;cycle();
        if(score_bcd!=16'h0150) $fatal(1,"Target score or carry failed");
        timer_before_pause=dut.bonus_timer;
        @(negedge clk);pause_press=1;cycle();@(negedge clk);pause_press=0;cycle();
        if(state!=3 || active) $fatal(1,"Pause failed");
        repeat(100)game_tick();
        if(score_bcd!=16'h0150 || dut.bonus_timer!=timer_before_pause) $fatal(1,"Pause changed game data");
        @(negedge clk);pause_press=1;cycle();@(negedge clk);pause_press=0;cycle();
        if(state!=2) $fatal(1,"Resume failed");
        repeat(241)game_tick();
        if(!bonus_active) $fatal(1,"Bonus window failed");
        @(negedge clk);hit_events=5'b00001<<bonus_target;cycle();
        @(negedge clk);hit_events=0;cycle();
        if(score_bcd!=16'h0450 || bonus_active) $fatal(1,"Bonus scoring/consume failed");
        // A registered physics hit can complete after the pause transition.
        // It retains the bonus that was available during the PLAY update.
        repeat(241)game_tick();
        if(!bonus_active) $fatal(1,"Second bonus window failed");
        late_bonus_target=bonus_target;
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;hit_events=5'b00001<<late_bonus_target;cycle();
        @(negedge clk);hit_events=0;cycle();
        if(state!=3 || score_bcd!=16'h0750 || high_bcd!=16'h0750 ||
            !hit_flash[late_bonus_target] || dut.bonus_timer!=720)
            $fatal(1,"Paused in-flight bonus hit was lost or not consumed");
        repeat(5)game_tick();
        if(dut.bonus_timer!=720) $fatal(1,"Paused bonus timer advanced");
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;cycle();
        if(state!=2 || bonus_active) $fatal(1,"Late bonus resume failed");
        // Saturating decimal scoring, including carry across all digits.
        force dut.score_bcd=16'h9950;
        cycle();release dut.score_bcd;
        @(negedge clk);hit_events=8;cycle();@(negedge clk);hit_events=0;cycle();
        if(score_bcd!=16'h9999 || high_bcd!=16'h9999) $fatal(1,"Score saturation failed");
        // A drain arriving one clock after pause must consume its life and
        // prepare the next ball while retaining the paused user state.
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;drained=1;cycle();
        if(state!=3 || lives!=2 || !prepare || dut.resume_state!=1)
            $fatal(1,"Paused in-flight drain was lost");
        @(negedge clk);drained=0;cycle();
        if(prepare) $fatal(1,"Late drain prepare was not a one-clock pulse");
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;cycle();
        if(state!=1 || lives!=2 || active) $fatal(1,"Paused drain resumed into stalled play");
        // Holding C continuously through a READY pause restarts its charge
        // from zero on resume; it never retains the old spring power.
        @(negedge clk);launch_down=1;repeat(24)game_tick();
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;cycle();
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;cycle();
        if(state!=1 || charge!=0 || launch) $fatal(1,"Held READY pause retained stale charge");
        shoot();lose_ball();if(state!=1 || lives!=1) $fatal(1,"Second drain failed");
        shoot();
        @(negedge clk);pause_press=1;cycle();
        @(negedge clk);pause_press=0;drained=1;cycle();
        if(state!=4 || lives!=0 || prepare) $fatal(1,"Paused final drain did not reach game over");
        @(negedge clk);drained=0;cycle();
        start();if(score_bcd!=0 || high_bcd!=16'h9999 || lives!=3) $fatal(1,"Restart/high score failed");
        @(negedge clk);menu_press=1;cycle();@(negedge clk);menu_press=0;cycle();
        if(state!=0 || high_bcd!=16'h9999) $fatal(1,"Return to menu failed");
        $display("PASS tb_game: FSM, charge, scoring, bonus, late pause hit/drain, lives, saturation, high score");
        $finish;
    end
endmodule

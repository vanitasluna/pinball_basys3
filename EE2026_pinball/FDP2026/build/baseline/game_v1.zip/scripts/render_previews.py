"""Convert exact RGB565 frames from tb_renderer into OLED preview PNGs."""
from pathlib import Path
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parent.parent
out = root / "docs"
out.mkdir(exist_ok=True)
labels = ["MENU", "READY", "PLAY", "PAUSE", "GAME OVER"]
canvas = Image.new("RGB", (1152, 580), (18, 24, 36))
draw = ImageDraw.Draw(canvas)
for i, label in enumerate(labels):
    values = [int(t, 16) for t in (root / "tests" / f"render_{i}.hex").read_text().split()]
    assert len(values) == 96 * 64
    im = Image.new("RGB", (96, 64))
    im.putdata([((v >> 11) * 255 // 31, ((v >> 5) & 63) * 255 // 63,
                 (v & 31) * 255 // 31) for v in values])
    im.save(out / (label.lower().replace(" ", "_") + ".png"))
    x, y = (i % 3) * 384, (i // 3) * 290
    canvas.paste(im.resize((384, 256), Image.Resampling.NEAREST), (x, y + 24))
    draw.text((x + 12, y + 6), label, fill="white")
canvas.save(out / "display_preview.png")
print(out / "display_preview.png")

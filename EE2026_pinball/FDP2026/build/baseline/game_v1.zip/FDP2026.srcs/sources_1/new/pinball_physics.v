`timescale 1ns / 1ps

// 100 MHz clock, with a one-clock tick enable at 240 Hz. Reset, prepare and
// launch are processed on the main clock, independently of the slow tick.
module pinball_physics (
    input clk,
    input reset,
    input tick,
    input active,
    input prepare,
    input launch,
    input [5:0] launch_power,
    input [1:0] difficulty,
    input left_pressed,
    input right_pressed,
    output [6:0] ball_x,
    output [5:0] ball_y,
    output reg [2:0] left_angle,
    output reg [2:0] right_angle,
    output reg drained,
    output reg [4:0] hit_events,
    output reg in_lane
);
    reg signed [15:0] position_x, position_y;
    reg signed [15:0] velocity_x, velocity_y;
    reg launched;
    reg [5:0] shot_power;
    reg [4:0] hit_armed;
    reg [4:0] cooldown [0:4];
    reg collision_busy;
    reg [4:0] collision_wait;

    // Collision is a deliberately multi-cycle combinational calculation.
    // Every operand is isolated here and remains stable for 16 system
    // clocks before the corrected result is committed. The matching XDC
    // exceptions apply only from these snapshot registers to result state.
    (* KEEP = "TRUE" *) reg signed [15:0] collision_proposed_x, collision_proposed_y;
    (* KEEP = "TRUE" *) reg signed [15:0] collision_velocity_x, collision_velocity_y;
    (* KEEP = "TRUE" *) reg signed [15:0] collision_previous_x, collision_previous_y;
    (* KEEP = "TRUE" *) reg collision_in_lane;
    (* KEEP = "TRUE" *) reg [2:0] collision_left_angle, collision_right_angle;
    (* KEEP = "TRUE" *) reg collision_left_pressed, collision_right_pressed;
    (* KEEP = "TRUE" *) reg collision_left_moving, collision_right_moving;
    integer k;

    wire [2:0] next_left_angle = left_pressed ?
        ((left_angle < 4) ? left_angle + 1'b1 : left_angle) :
        ((left_angle != 0) ? left_angle - 1'b1 : left_angle);
    wire [2:0] next_right_angle = right_pressed ?
        ((right_angle < 4) ? right_angle + 1'b1 : right_angle) :
        ((right_angle != 0) ? right_angle - 1'b1 : right_angle);
    wire left_moving = left_pressed && (left_angle < 4);
    wire right_moving = right_pressed && (right_angle < 4);

    // A small difficulty-dependent gravity increase makes the fast table
    // demand quicker timing. Both presets retain the same launch reach.
    wire signed [15:0] gravity = (difficulty == 2'd0) ? 16'sd1 :
                               (difficulty == 2'd1) ? 16'sd2 : 16'sd3;
    wire signed [15:0] accelerated_vy = clamp_speed(velocity_y + gravity);
    wire signed [15:0] proposed_x = position_x + velocity_x;
    wire signed [15:0] proposed_y = position_y + accelerated_vy;
    wire signed [15:0] corrected_x, corrected_y, corrected_vx, corrected_vy;
    wire [4:0] contact_events;
    wire [4:0] far_from_object;

    function signed [15:0] clamp_speed;
        input signed [15:0] value;
        begin
            if (value > 16'sd384) clamp_speed = 16'sd384;
            else if (value < -16'sd384) clamp_speed = -16'sd384;
            else clamp_speed = value;
        end
    endfunction

    function [15:0] magnitude;
        input signed [15:0] value;
        begin
            magnitude = (value < 0) ? -value : value;
        end
    endfunction

    // Outputs saturate so the OLED address never wraps before a drain is
    // consumed. Fractional position still accumulates in Q8 internally.
    assign ball_x = (position_x < 0) ? 7'd0 :
                    (position_x >= 16'sd24320) ? 7'd95 : position_x[14:8];
    assign ball_y = (position_y < 0) ? 6'd0 :
                    (position_y >= 16'sd16128) ? 6'd63 : position_y[13:8];

    assign far_from_object[0] =
        (magnitude(position_x - 16'sd6656) > 16'd2304) ||
        (magnitude(position_y - 16'sd5632) > 16'd2304);
    assign far_from_object[1] =
        (magnitude(position_x - 16'sd14848) > 16'd2304) ||
        (magnitude(position_y - 16'sd5632) > 16'd2304);
    assign far_from_object[2] =
        (magnitude(position_x - 16'sd10752) > 16'd2304) ||
        (magnitude(position_y - 16'sd8960) > 16'd2304);
    assign far_from_object[3] = (position_x > 16'sd3328) ||
        (position_y < 16'sd6400) || (position_y > 16'sd10496);
    assign far_from_object[4] = (position_x < 16'sd18432) ||
        (position_y < 16'sd6400) || (position_y > 16'sd10496);

    pinball_collision collisions (
        .proposed_x(collision_proposed_x), .proposed_y(collision_proposed_y),
        .velocity_x(collision_velocity_x), .velocity_y(collision_velocity_y),
        .previous_x(collision_previous_x), .previous_y(collision_previous_y),
        .in_lane(collision_in_lane),
        .left_angle(collision_left_angle), .right_angle(collision_right_angle),
        .left_pressed(collision_left_pressed), .right_pressed(collision_right_pressed),
        .left_moving(collision_left_moving), .right_moving(collision_right_moving),
        .corrected_x(corrected_x), .corrected_y(corrected_y),
        .corrected_vx(corrected_vx), .corrected_vy(corrected_vy),
        .hit_events(contact_events)
    );

    always @(posedge clk) begin
        drained <= 1'b0;
        hit_events <= 5'b00000;
        if (reset || prepare) begin
            position_x <= 16'sd22784; // shooter lane x=89, y=56
            position_y <= 16'sd14336;
            velocity_x <= 0;
            velocity_y <= 0;
            launched <= 1'b0;
            shot_power <= 0;
            in_lane <= 1'b1;
            left_angle <= 0;
            right_angle <= 0;
            hit_armed <= 5'b11111;
            collision_busy <= 1'b0;
            collision_wait <= 0;
            collision_proposed_x <= 16'sd22784;
            collision_proposed_y <= 16'sd14336;
            collision_previous_x <= 16'sd22784;
            collision_previous_y <= 16'sd14336;
            collision_velocity_x <= 0;
            collision_velocity_y <= 0;
            collision_in_lane <= 1'b1;
            collision_left_angle <= 0;
            collision_right_angle <= 0;
            collision_left_pressed <= 0;
            collision_right_pressed <= 0;
            collision_left_moving <= 0;
            collision_right_moving <= 0;
            for (k = 0; k < 5; k = k + 1) cooldown[k] <= 0;
        end else begin
            // Capturing a launch does not depend on coinciding with tick.
            if (launch && in_lane && !launched) begin
                launched <= 1'b1;
                shot_power <= launch_power;
                // Even the lightest shot clears the lane on hard mode.
                velocity_y <= -16'sd288 - $signed({10'b0, launch_power});
                velocity_x <= 0;
            end
            if (tick && active) begin
                left_angle <= next_left_angle;
                right_angle <= next_right_angle;
                for (k = 0; k < 5; k = k + 1) begin
                    if (cooldown[k] != 0) cooldown[k] <= cooldown[k] - 1'b1;
                    else if (far_from_object[k]) hit_armed[k] <= 1'b1;
                end
                if (launched && !launch && !collision_busy) begin
                    collision_proposed_x <= proposed_x;
                    collision_proposed_y <= proposed_y;
                    collision_velocity_x <= velocity_x;
                    collision_velocity_y <= accelerated_vy;
                    collision_previous_x <= position_x;
                    collision_previous_y <= position_y;
                    collision_in_lane <= in_lane;
                    collision_left_angle <= next_left_angle;
                    collision_right_angle <= next_right_angle;
                    collision_left_pressed <= left_pressed;
                    collision_right_pressed <= right_pressed;
                    collision_left_moving <= left_moving;
                    collision_right_moving <= right_moving;
                    collision_busy <= 1'b1;
                    collision_wait <= 5'd16;
                end
            end
            if (collision_busy) begin
                if (collision_wait > 1) begin
                    collision_wait <= collision_wait - 1'b1;
                end else begin
                    collision_busy <= 1'b0;
                    collision_wait <= 0;
                    position_x <= corrected_x;
                    position_y <= corrected_y;
                    velocity_x <= clamp_speed(corrected_vx);
                    velocity_y <= clamp_speed(corrected_vy);
                    for (k = 0; k < 5; k = k + 1) begin
                        if (!collision_in_lane && contact_events[k] && hit_armed[k]) begin
                            hit_events[k] <= 1'b1;
                            hit_armed[k] <= 1'b0;
                            cooldown[k] <= 5'd16;
                        end
                    end
                    if (collision_in_lane && collision_proposed_y <= 16'sd3840) begin
                        in_lane <= 1'b0;
                        // The exit arch introduces a reproducible launch
                        // spread from the player's captured spring power.
                        velocity_x <= -16'sd192 - $signed({9'b0, shot_power, 1'b0});
                        velocity_y <= -16'sd56;
                    end
                    if (!collision_in_lane && corrected_y >= 16'sd16384 &&
                        corrected_x >= 16'sd7936 && corrected_x <= 16'sd14080) begin
                        drained <= 1'b1;
                        launched <= 1'b0;
                        velocity_x <= 0;
                        velocity_y <= 0;
                    end
                end
            end
        end
    end
endmodule

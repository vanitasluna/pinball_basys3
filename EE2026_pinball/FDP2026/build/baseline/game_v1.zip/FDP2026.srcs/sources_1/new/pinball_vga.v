`timescale 1ns / 1ps
// 640x480 at 59.52 Hz with a 25 MHz pixel clock. Sixfold OLED mirror.
module pinball_vga(input clk,reset, input [15:0] pixel,
    output [6:0] x, output [5:0] y, output frame_begin,
    output reg [3:0] red,green,blue, output reg hsync,vsync);
    reg [9:0] h;
    reg [9:0] v;
    wire inside = h>=32 && h<608 && v>=48 && v<432;
    assign x=inside ? (h-10'd32)/6 : 0;
    assign y=inside ? (v-10'd48)/6 : 0;
    assign frame_begin=h==0 && v==0;
    always @(posedge clk) begin
        if(reset) begin h<=0; v<=0; red<=0; green<=0; blue<=0; hsync<=1; vsync<=1; end
        else begin
            if(h==799) begin h<=0; v<=v==524 ? 0 : v+1'b1; end
            else h<=h+1'b1;
            hsync<=!(h>=656 && h<752);
            vsync<=!(v>=490 && v<492);
            red<=inside ? pixel[15:12] : 0;
            green<=inside ? pixel[10:7] : 0;
            blue<=inside ? pixel[4:1] : 0;
        end
    end
endmodule

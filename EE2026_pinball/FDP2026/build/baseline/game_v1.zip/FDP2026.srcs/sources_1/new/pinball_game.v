`timescale 1ns / 1ps
// Rules, BCD scoring, charge-to-launch, three lives, pause and random bonuses.
module pinball_game (
    input clk, reset, tick,
    input start_press, launch_down, pause_press, menu_press,
    input level_left, level_right,
    input drained, input [4:0] hit_events,
    output reg [2:0] state,
    output reg [1:0] lives, difficulty,
    output reg [15:0] score_bcd, high_bcd,
    output reg [5:0] charge,
    output reg prepare, launch,
    output active,
    output [4:0] hit_flash,
    output reg [1:0] bonus_target,
    output bonus_active,
    output reg [7:0] anim
);
    localparam MENU=0, READY=1, PLAY=2, PAUSE=3, OVER=4;
    reg [2:0] resume_state;
    reg charging;
    reg [1:0] charge_div;
    reg [9:0] bonus_timer;
    reg [15:0] rng;
    reg [4:0] flash_timer [0:4];
    reg [15:0] award, updated_score;
    reg [4:0] award_tens;
    reg [3:0] award_hundreds;
    integer i;
    assign active = state == PLAY;
    assign bonus_active = state == PLAY && bonus_timer != 0 && bonus_timer <= 480;
    // Physics commits can arrive after the pause button has changed the FSM.
    // Accept the final in-flight PLAY result, including its bonus entitlement.
    wire accepts_play_event = state == PLAY || (state == PAUSE && resume_state == PLAY);
    wire bonus_available = accepts_play_event && bonus_timer != 0 && bonus_timer <= 480;
    wire bonus_hit = bonus_available && hit_events[bonus_target];
    genvar g;
    generate for(g=0;g<5;g=g+1) begin: flashes
        assign hit_flash[g] = flash_timer[g] != 0;
    end endgenerate

    // Decimal carry in each nibble; score saturates at 9999.
    function [15:0] add_bcd;
        input [15:0] a,b;
        reg [4:0] d;
        reg carry;
        reg [15:0] result;
        integer k;
        begin
            carry=0; result=0;
            for(k=0;k<4;k=k+1) begin
                d={1'b0,a[k*4+:4]}+{1'b0,b[k*4+:4]}+carry;
                carry=d>=10;
                result[k*4+:4]=carry ? d-10 : d;
            end
            add_bcd=carry ? 16'h9999 : result;
        end
    endfunction
    always @* begin
        award_tens=({4'd0,hit_events[0]}+{4'd0,hit_events[1]}+
            {4'd0,hit_events[2]})*5'd5;
        award_hundreds={3'd0,hit_events[3]}+{3'd0,hit_events[4]};
        if(bonus_hit) begin
            award_tens=award_tens+5'd5;
            award_hundreds=award_hundreds+4'd2;
        end
        if(award_tens>=20) begin
            award_tens=award_tens-5'd20; award_hundreds=award_hundreds+4'd2;
        end else if(award_tens>=10) begin
            award_tens=award_tens-5'd10; award_hundreds=award_hundreds+1'b1;
        end
        award={4'd0,award_hundreds,award_tens[3:0],4'd0};
        updated_score=add_bcd(score_bcd,award);
    end
    always @(posedge clk) begin
        if(reset) begin
            state<=MENU; resume_state<=PLAY; lives<=3; difficulty<=1;
            score_bcd<=0; high_bcd<=0; charge<=0; charge_div<=0;
            charging<=0; prepare<=0; launch<=0; bonus_timer<=720;
            bonus_target<=0; rng<=16'hACE1; anim<=0;
            for(i=0;i<5;i=i+1) flash_timer[i]<=0;
        end else begin
            rng<={rng[14:0],rng[15]^rng[13]^rng[12]^rng[10]};
            prepare<=0; launch<=0;
            // Independent comparison keeps the best-score path short. The
            // best score catches a new score on the next 100 MHz edge.
            if(score_bcd>high_bcd) high_bcd<=score_bcd;
            if(tick && state!=PAUSE) begin
                anim<=anim+1'b1;
                for(i=0;i<5;i=i+1)
                    if(flash_timer[i]!=0) flash_timer[i]<=flash_timer[i]-1'b1;
            end
            // A completed physics result is handled before state transitions,
            // so pausing cannot discard a score or the last ball's drain.
            if(accepts_play_event && |hit_events) begin
                score_bcd<=updated_score;
                for(i=0;i<5;i=i+1) if(hit_events[i]) flash_timer[i]<=24;
                if(bonus_hit) begin
                    bonus_timer<=720;
                    bonus_target<=rng[1:0]==3 ? 0 : rng[1:0];
                end
            end
            // Returning to the menu preserves the session high score.
            if(menu_press) begin
                state<=MENU; charging<=0; charge<=0; prepare<=1;
            end else if(drained && accepts_play_event) begin
                charge<=0; charge_div<=0; charging<=0;
                if(lives<=1) begin lives<=0; state<=OVER; end
                else begin
                    lives<=lives-1'b1; prepare<=1;
                    if(state==PAUSE) begin
                        state<=PAUSE; resume_state<=READY;
                    end else state<=READY;
                end
            end else case(state)
                MENU: begin
                    if(level_left) difficulty<=difficulty==0 ? 2 : difficulty-1'b1;
                    else if(level_right) difficulty<=difficulty==2 ? 0 : difficulty+1'b1;
                    if(start_press) begin
                        state<=READY; score_bcd<=0; lives<=3; prepare<=1;
                        charge<=0; charge_div<=0; charging<=0; bonus_timer<=720;
                        bonus_target<=rng[1:0]==3 ? 0 : rng[1:0];
                        for(i=0;i<5;i=i+1) flash_timer[i]<=0;
                    end
                end
                READY: begin
                    if(pause_press) begin resume_state<=READY; state<=PAUSE; end
                    else if(launch_down) begin
                        charging<=1;
                        if(tick) begin
                            charge_div<=charge_div+1'b1;
                            if(charge_div==3 && charge<63) charge<=charge+1'b1;
                        end
                    end else if(charging) begin
                        // A tap still gives enough energy to leave the shooter lane.
                        if(charge<16) charge<=16;
                        launch<=1; state<=PLAY; charging<=0;
                    end
                end
                PLAY: begin
                    if(tick && !bonus_hit) begin
                        if(bonus_timer==0) begin
                            bonus_timer<=720;
                            bonus_target<=rng[1:0]==3 ? 0 : rng[1:0];
                        end else bonus_timer<=bonus_timer-1'b1;
                    end
                    if(pause_press) begin resume_state<=PLAY; state<=PAUSE; end
                end
                PAUSE: if(pause_press || start_press) begin
                    state<=resume_state;
                    // Charge has to be held again after pausing a ready ball.
                    charging<=0; charge<=0; charge_div<=0;
                end
                OVER: if(start_press) begin
                    state<=READY; score_bcd<=0; lives<=3; prepare<=1;
                    charging<=0; charge<=0; charge_div<=0; bonus_timer<=720;
                    for(i=0;i<5;i=i+1) flash_timer[i]<=0;
                end
                default: state<=MENU;
            endcase
        end
    end
endmodule

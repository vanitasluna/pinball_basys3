`timescale 1ns / 1ps

//////////////////////////////////////////////////////////////////////////////////
//  FILL IN THE FOLLOWING INFORMATION:
//  STUDENT A NAME: 
//  STUDENT B NAME:
//  STUDENT C NAME: 
//  STUDENT D NAME:  
//////////////////////////////////////////////////////////////////////////////////

// OLED: plug Pmod OLEDrgb into JA. Mouse: Basys 3 USB HID host port.
// C hold/release: start/launch; L/R: flippers or menu level; U: pause; D: menu.
// SW0 enables mouse controls; SW15 resets the entire system.
module My_Top_Module (
    input clk, input btnC,btnU,btnL,btnR,btnD, input [15:0] sw,
    output [7:0] JA, inout PS2Clk,PS2Data,
    output [15:0] led, output [6:0] seg, output [3:0] an, output dp,
    output [3:0] vgaRed,vgaGreen,vgaBlue, output Hsync,Vsync
);
    reg [31:0] power_on = 32'hFFFFFFFF;
    reg [3:0] divider = 0;
    reg system_reset = 1;
    (* ASYNC_REG = "TRUE" *) reg [15:0] sw_meta=0, sw_sync=0;
    always @(posedge clk) begin
        power_on <= {power_on[30:0],1'b0};
        divider <= divider+1'b1;
        sw_meta<=sw; sw_sync<=sw_meta;
        system_reset <= (|power_on) || sw_sync[15];
    end
    wire reset = system_reset;
    wire oled_clk, vga_clk;
    BUFG oled_clock_buffer(.I(divider[3]),.O(oled_clk));
    BUFG vga_clock_buffer(.I(divider[1]),.O(vga_clk));
    reg [18:0] tick_count;
    wire tick=tick_count==416666-1;
    always @(posedge clk)
        if(reset || tick) tick_count<=0; else tick_count<=tick_count+1'b1;

    wire [4:0] buttons,button_press;
    pinball_input inputs(.clk(clk),.reset(reset),.raw({btnD,btnR,btnL,btnU,btnC}),
        .down(buttons),.pressed(button_press));
    wire [11:0] mouse_x,mouse_y;
    wire [3:0] mouse_z;
    wire mouse_left,mouse_middle,mouse_right,mouse_event;
    reg [2:0] mouse_config;
    always @(posedge clk) if(reset) mouse_config<=0;
        else if(mouse_config<4) mouse_config<=mouse_config+1'b1;
    wire [11:0] mouse_value = mouse_config==0 ? 12'd95 :
        mouse_config==1 ? 12'd63 : mouse_config==2 ? 12'd48 : 12'd32;
    MouseCtl mouse(.clk(clk),.rst(reset),.xpos(mouse_x),.ypos(mouse_y),.zpos(mouse_z),
        .left(mouse_left),.middle(mouse_middle),.right(mouse_right),.new_event(mouse_event),
        .value(mouse_value),.setmax_x(!reset && mouse_config==0),
        .setmax_y(!reset && mouse_config==1),.setx(!reset && mouse_config==2),
        .sety(!reset && mouse_config==3),.ps2_clk(PS2Clk),.ps2_data(PS2Data));
    reg [2:0] mouse_prev;
    reg mouse_seen;
    reg mouse_event_d;
    always @(posedge clk) begin
        if(reset) begin mouse_prev<=0; mouse_seen<=0; mouse_event_d<=0; end
        else begin
            mouse_event_d<=mouse_event;
            // Track complete packets after the supplied controller has also
            // registered the new cursor Y position (including non-wheel mice).
            if(mouse_event_d) mouse_prev<={mouse_right,mouse_middle,mouse_left};
            if(mouse_event) mouse_seen<=1;
        end
    end
    wire mouse_click=sw_sync[0] && mouse_event_d && mouse_left && !mouse_prev[0];
    wire [6:0] cursor_x=mouse_x>95 ? 7'd95 : mouse_x[6:0];
    wire [5:0] cursor_y=mouse_y>63 ? 6'd63 : mouse_y[5:0];
    wire [2:0] state;
    wire [1:0] lives,difficulty,bonus_target;
    wire [15:0] score_bcd,high_bcd;
    wire [5:0] charge;
    wire [4:0] hit_events,hit_flash;
    wire [7:0] anim;
    wire prepare,launch,active,drained,in_lane,bonus_active;
    wire left_pressed=buttons[2] || (sw_sync[0] && mouse_seen && mouse_left);
    wire right_pressed=buttons[3] || (sw_sync[0] && mouse_seen && mouse_right);
    wire launch_down=buttons[0] || (sw_sync[0] && mouse_seen && mouse_middle);
    // Left mouse click selects a difficulty row or starts/restarts the game.
    wire mouse_level=state==0 && cursor_y>=30 && cursor_y<=39;
    pinball_game game(.clk(clk),.reset(reset),.tick(tick),
        .start_press(button_press[0] || (mouse_click && !mouse_level)),
        .launch_down(launch_down),.pause_press(button_press[1]),.menu_press(button_press[4]),
        .level_left(button_press[2] || (mouse_click && mouse_level && cursor_x<48)),
        .level_right(button_press[3] || (mouse_click && mouse_level && cursor_x>=48)),
        .drained(drained),.hit_events(hit_events),.state(state),.lives(lives),
        .difficulty(difficulty),.score_bcd(score_bcd),.high_bcd(high_bcd),.charge(charge),
        .prepare(prepare),.launch(launch),.active(active),.hit_flash(hit_flash),
        .bonus_target(bonus_target),.bonus_active(bonus_active),.anim(anim));
    wire [6:0] ball_x;
    wire [5:0] ball_y;
    wire [2:0] left_angle,right_angle;
    pinball_physics physics(.clk(clk),.reset(reset),.tick(tick),.active(active),
        .prepare(prepare),.launch(launch),.launch_power(charge),.difficulty(difficulty),
        .left_pressed(left_pressed),.right_pressed(right_pressed),
        .ball_x(ball_x),.ball_y(ball_y),.left_angle(left_angle),.right_angle(right_angle),
        .drained(drained),.hit_events(hit_events),.in_lane(in_lane));
    pinball_sevenseg score_display(.clk(clk),.reset(reset),.bcd(score_bcd),
        .seg(seg),.an(an),.dp(dp));
    assign led={state==4,state==3,active,in_lane,bonus_active,difficulty,
        charge[5:1],sw_sync[0] && mouse_seen,lives>=3,lives>=2,lives>=1};

    wire [93:0] live_scene={state,ball_x,ball_y,left_angle,right_angle,score_bcd,
        high_bcd,lives,difficulty,charge,hit_flash,bonus_target,bonus_active,anim,
        cursor_x,cursor_y,sw_sync[0] && mouse_seen};
    reg [93:0] oled_scene,vga_scene;
    wire oled_frame,vga_frame;
    // Related BUFG clocks are timed by generated-clock constraints. Latch the
    // complete scene once per display frame so moving objects never tear.
    always @(posedge oled_clk)
        if(reset) oled_scene<=0; else if(oled_frame) oled_scene<=live_scene;
    always @(posedge vga_clk)
        if(reset) vga_scene<=0; else if(vga_frame) vga_scene<=live_scene;
    wire [12:0] pixel_index;
    wire [6:0] oled_x=pixel_index%96;
    wire [5:0] oled_y=pixel_index/96;
    wire [15:0] oled_pixel,vga_pixel;
    wire sending_pixels,sample_pixel;
    pinball_scene oled_graphics(.scene(oled_scene),.x(oled_x),.y(oled_y),.pixel(oled_pixel));
    Oled_Display oled(.clk(oled_clk),.reset(reset),.frame_begin(oled_frame),
        .sending_pixels(sending_pixels),.sample_pixel(sample_pixel),
        .pixel_index(pixel_index),.pixel_data(oled_pixel),
        .cs(JA[0]),.sdin(JA[1]),.sclk(JA[3]),.d_cn(JA[4]),.resn(JA[5]),
        .vccen(JA[6]),.pmoden(JA[7]));
    assign JA[2]=1'b0; // OLEDrgb pin 3 is not connected.
    wire [6:0] vga_x;
    wire [5:0] vga_y;
    pinball_scene vga_graphics(.scene(vga_scene),.x(vga_x),.y(vga_y),.pixel(vga_pixel));
    pinball_vga video(.clk(vga_clk),.reset(reset),.pixel(vga_pixel),.x(vga_x),.y(vga_y),
        .frame_begin(vga_frame),.red(vgaRed),.green(vgaGreen),.blue(vgaBlue),
        .hsync(Hsync),.vsync(Vsync));
endmodule

module pinball_scene(input [93:0] scene,input [6:0] x,input [5:0] y,output [15:0] pixel);
    wire [2:0] state,left_angle,right_angle;
    wire [6:0] ball_x,cursor_x;
    wire [5:0] ball_y,charge,cursor_y;
    wire [15:0] score_bcd,high_bcd;
    wire [1:0] lives,difficulty,bonus_target;
    wire [4:0] hit_flash;
    wire [7:0] anim;
    wire bonus_active,cursor_visible;
    assign {state,ball_x,ball_y,left_angle,right_angle,score_bcd,high_bcd,lives,
        difficulty,charge,hit_flash,bonus_target,bonus_active,anim,cursor_x,cursor_y,
        cursor_visible}=scene;
    pinball_renderer graphics(.x(x),.y(y),.state(state),.ball_x(ball_x),.ball_y(ball_y),
        .left_angle(left_angle),.right_angle(right_angle),.score_bcd(score_bcd),
        .high_bcd(high_bcd),.lives(lives),.difficulty(difficulty),.charge(charge),
        .hit_flash(hit_flash),.bonus_target(bonus_target),.bonus_active(bonus_active),
        .anim(anim),.cursor_x(cursor_x),.cursor_y(cursor_y),
        .cursor_visible(cursor_visible),.pixel(pixel));
endmodule

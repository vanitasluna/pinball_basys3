`timescale 1ns / 1ps

// All positions and velocities are signed Q8 (256 units per OLED pixel).
// The ball has radius two. Eight-direction bumper normals avoid dividers,
// square roots and trigonometric hardware while giving repeatable rebounds.
module pinball_collision (
    input signed [15:0] proposed_x,
    input signed [15:0] proposed_y,
    input signed [15:0] velocity_x,
    input signed [15:0] velocity_y,
    input signed [15:0] previous_x,
    input signed [15:0] previous_y,
    input in_lane,
    input [2:0] left_angle,
    input [2:0] right_angle,
    input left_pressed,
    input right_pressed,
    input left_moving,
    input right_moving,
    output reg signed [15:0] corrected_x,
    output reg signed [15:0] corrected_y,
    output reg signed [15:0] corrected_vx,
    output reg signed [15:0] corrected_vy,
    output reg [4:0] hit_events
);

    reg signed [15:0] centre_x, centre_y;
    reg signed [15:0] dx, dy;
    reg [15:0] ax, ay;
    reg signed [15:0] old_vx, old_vy;
    reg signed [16:0] approach;
    reg signed [31:0] line_y, previous_line_y;
    reg signed [31:0] local_x;
    reg signed [31:0] previous_local_x;
    reg signed [31:0] slope;
    reg signed [31:0] lower_bound;
    reg solid_contact;
    reg sx, sy;
    integer i;

    function [15:0] magnitude;
        input signed [15:0] value;
        begin
            magnitude = (value < 0) ? -value : value;
        end
    endfunction

    // Inner tip heights, relative to the pivot at y = 53.
    function signed [31:0] tip_offset;
        input [2:0] angle;
        begin
            case (angle)
                3'd0: tip_offset = 5;
                3'd1: tip_offset = 3;
                3'd2: tip_offset = 1;
                3'd3: tip_offset = -2;
                default: tip_offset = -4;
            endcase
        end
    endfunction

    always @* begin
        corrected_x = proposed_x;
        corrected_y = proposed_y;
        corrected_vx = velocity_x;
        corrected_vy = velocity_y;
        hit_events = 5'b00000;
        centre_x = 0;
        centre_y = 0;
        dx = 0;
        dy = 0;
        ax = 0;
        ay = 0;
        old_vx = 0;
        old_vy = 0;
        approach = 0;
        line_y = 0;
        previous_line_y = 0;
        local_x = 0;
        previous_local_x = 0;
        slope = 0;
        lower_bound = 0;
        solid_contact = 1'b0;
        sx = 1'b0;
        sy = 1'b0;

        if (!in_lane) begin
            // Radius-six collision octagons enclose the drawn radius-four
            // bumpers and ball. Priority is left, right, then centre bumper.
            for (i = 0; i < 3; i = i + 1) begin
                case (i)
                    0: begin centre_x = 16'sd6656; centre_y = 16'sd5632; end
                    1: begin centre_x = 16'sd14848; centre_y = 16'sd5632; end
                    default: begin centre_x = 16'sd10752; centre_y = 16'sd8960; end
                endcase
                dx = proposed_x - centre_x;
                dy = proposed_y - centre_y;
                ax = magnitude(dx);
                ay = magnitude(dy);
                if (!solid_contact && ax <= 16'd1536 && ay <= 16'd1536 &&
                    ({1'b0, ax} + {1'b0, ay}) <= 17'd2176) begin
                    solid_contact = 1'b1;
                    sx = (dx >= 0);
                    sy = (dy >= 0);
                    old_vx = corrected_vx;
                    old_vy = corrected_vy;
                    if (ax > (ay << 1)) begin
                        corrected_x = centre_x + (sx ? 16'sd1664 : -16'sd1664);
                        approach = sx ? old_vx : -old_vx;
                        if (approach < 0) begin
                            corrected_vx = sx ?
                                $signed((magnitude(old_vx) * 7) >> 3) + 16'sd24 :
                                -$signed((magnitude(old_vx) * 7) >> 3) - 16'sd24;
                            if (magnitude(corrected_vx) < 16'd160)
                                corrected_vx = sx ? 16'sd160 : -16'sd160;
                            hit_events[i] = 1'b1;
                        end
                    end else if (ay > (ax << 1)) begin
                        corrected_y = centre_y + (sy ? 16'sd1664 : -16'sd1664);
                        approach = sy ? old_vy : -old_vy;
                        if (approach < 0) begin
                            corrected_vy = sy ?
                                $signed((magnitude(old_vy) * 7) >> 3) + 16'sd24 :
                                -$signed((magnitude(old_vy) * 7) >> 3) - 16'sd24;
                            if (magnitude(corrected_vy) < 16'd160)
                                corrected_vy = sy ? 16'sd160 : -16'sd160;
                            hit_events[i] = 1'b1;
                        end
                    end else begin
                        corrected_x = centre_x + (sx ? 16'sd1280 : -16'sd1280);
                        corrected_y = centre_y + (sy ? 16'sd1280 : -16'sd1280);
                        approach = (sx ? old_vx : -old_vx) +
                                   (sy ? old_vy : -old_vy);
                        if (approach < 0) begin
                            // Reflection about a 45-degree normal swaps the
                            // components. A small radial impulse livens play.
                            corrected_vx = (sx == sy) ? -old_vy : old_vy;
                            corrected_vy = (sx == sy) ? -old_vx : old_vx;
                            corrected_vx = corrected_vx + (sx ? 16'sd32 : -16'sd32);
                            corrected_vy = corrected_vy + (sy ? 16'sd32 : -16'sd32);
                            hit_events[i] = 1'b1;
                        end
                    end
                end
            end

            // Side targets extend two pixels beyond their drawn rectangles.
            if (!solid_contact && proposed_y >= 16'sd7168 && proposed_y <= 16'sd9728) begin
                if (proposed_x <= 16'sd2560) begin
                    corrected_x = 16'sd2688;
                    if (velocity_x < 0) begin
                        corrected_vx = $signed((magnitude(velocity_x) * 7) >> 3) + 16'sd32;
                        hit_events[3] = 1'b1;
                    end
                    solid_contact = 1'b1;
                end else if (proposed_x >= 16'sd19200) begin
                    corrected_x = 16'sd19072;
                    if (velocity_x > 0) begin
                        corrected_vx = -$signed((magnitude(velocity_x) * 7) >> 3) - 16'sd32;
                        hit_events[4] = 1'b1;
                    end
                    solid_contact = 1'b1;
                end
            end

            // Flippers: compare the old ball height with the surface, so a
            // ball travelling below a flipper is not teleported through it.
            // A rising flipper can sweep into a ball within its four-pixel
            // thickness. Constant division by 18 is synthesizable.
            if (!solid_contact && proposed_x >= 16'sd4864 && proposed_x <= 16'sd10496) begin
                local_x = $signed(proposed_x) - 32'sd5376;
                if (local_x < 0) local_x = 0;
                if (local_x > 32'sd4608) local_x = 32'sd4608;
                slope = tip_offset(left_angle);
                line_y = 32'sd13568 + (local_x * slope) / 18;
                previous_local_x = $signed(previous_x) - 32'sd5376;
                if (previous_local_x < 0) previous_local_x = 0;
                if (previous_local_x > 32'sd4608) previous_local_x = 32'sd4608;
                previous_line_y = 32'sd13568 + (previous_local_x * slope) / 18;
                if (proposed_y >= line_y - 32'sd640 && proposed_y <= line_y + 32'sd768 &&
                    ((velocity_y >= 0 && previous_y <= previous_line_y - 32'sd512) ||
                     (left_moving && previous_y <= previous_line_y + 32'sd768))) begin
                    corrected_y = line_y - 32'sd640;
                    corrected_x = proposed_x;
                    if (left_moving) begin
                        corrected_vy = -16'sd260 - (local_x >> 6);
                        corrected_vx = 16'sd48 + (local_x >> 5);
                    end else if (left_pressed && left_angle >= 3) begin
                        corrected_vy = -16'sd176 - (local_x >> 7);
                        corrected_vx = 16'sd40 + (local_x >> 6);
                    end else begin
                        if (velocity_y > 16'sd80) begin
                            corrected_vy = -$signed(magnitude(velocity_y) >> 1);
                            corrected_vx = velocity_x + 16'sd24;
                        end else begin
                            // At low energy the ball rolls down the released
                            // flipper towards its tip, rather than receiving
                            // an artificial upward impulse indefinitely.
                            corrected_vx = 16'sd48;
                            corrected_vy = (48 * slope) / 18;
                        end
                    end
                    solid_contact = 1'b1;
                end
            end
            if (!solid_contact && proposed_x >= 16'sd11520 && proposed_x <= 16'sd17152) begin
                local_x = 32'sd16640 - $signed(proposed_x);
                if (local_x < 0) local_x = 0;
                if (local_x > 32'sd4608) local_x = 32'sd4608;
                slope = tip_offset(right_angle);
                line_y = 32'sd13568 + (local_x * slope) / 18;
                previous_local_x = 32'sd16640 - $signed(previous_x);
                if (previous_local_x < 0) previous_local_x = 0;
                if (previous_local_x > 32'sd4608) previous_local_x = 32'sd4608;
                previous_line_y = 32'sd13568 + (previous_local_x * slope) / 18;
                if (proposed_y >= line_y - 32'sd640 && proposed_y <= line_y + 32'sd768 &&
                    ((velocity_y >= 0 && previous_y <= previous_line_y - 32'sd512) ||
                     (right_moving && previous_y <= previous_line_y + 32'sd768))) begin
                    corrected_y = line_y - 32'sd640;
                    corrected_x = proposed_x;
                    if (right_moving) begin
                        corrected_vy = -16'sd260 - (local_x >> 6);
                        corrected_vx = -16'sd48 - (local_x >> 5);
                    end else if (right_pressed && right_angle >= 3) begin
                        corrected_vy = -16'sd176 - (local_x >> 7);
                        corrected_vx = -16'sd40 - (local_x >> 6);
                    end else begin
                        if (velocity_y > 16'sd80) begin
                            corrected_vy = -$signed(magnitude(velocity_y) >> 1);
                            corrected_vx = velocity_x - 16'sd24;
                        end else begin
                            corrected_vx = -16'sd48;
                            corrected_vy = (48 * slope) / 18;
                        end
                    end
                    solid_contact = 1'b1;
                end
            end

            // Guides from (5,43) to (21,53), mirrored on the right, direct
            // descending side balls towards the flippers with no flat ledge.
            if (!solid_contact && velocity_y >= 0 && proposed_x < 16'sd5376 &&
                proposed_y >= 16'sd10240 && proposed_y < 16'sd14336) begin
                line_y = 32'sd11008 + (($signed(proposed_x) - 32'sd1280) * 10) / 16;
                if (proposed_y >= line_y - 32'sd512 && proposed_y <= line_y + 32'sd768) begin
                    corrected_y = line_y - 32'sd512;
                    corrected_vx = $signed((magnitude(velocity_y) * 3) >> 2) + 16'sd48;
                    corrected_vy = -$signed(magnitude(velocity_x) >> 1) - 16'sd48;
                    solid_contact = 1'b1;
                end
            end
            if (!solid_contact && velocity_y >= 0 && proposed_x > 16'sd16640 &&
                proposed_y >= 16'sd10240 && proposed_y < 16'sd14336) begin
                line_y = 32'sd11008 + ((32'sd20736 - $signed(proposed_x)) * 10) / 16;
                if (proposed_y >= line_y - 32'sd512 && proposed_y <= line_y + 32'sd768) begin
                    corrected_y = line_y - 32'sd512;
                    corrected_vx = -$signed((magnitude(velocity_y) * 3) >> 2) - 16'sd48;
                    corrected_vy = -$signed(magnitude(velocity_x) >> 1) - 16'sd48;
                    solid_contact = 1'b1;
                end
            end

            // Lower sloping walls narrow the ball centre corridor from
            // x=21..65 at y=54 to x=31..55 at y=64, into the drain.
            if (!solid_contact && corrected_y >= 16'sd13824) begin
                lower_bound = 32'sd5376 + ($signed(corrected_y) - 32'sd13824);
                if (lower_bound > 32'sd7936) lower_bound = 32'sd7936;
                if (corrected_x < lower_bound) begin
                    corrected_x = lower_bound;
                    corrected_vx = $signed((magnitude(velocity_y) * 3) >> 2) + 16'sd64;
                    corrected_vy = -$signed(magnitude(velocity_x) >> 1) - 16'sd24;
                end else if (corrected_x > 32'sd22016 - lower_bound) begin
                    corrected_x = 32'sd22016 - lower_bound;
                    corrected_vx = -$signed((magnitude(velocity_y) * 3) >> 2) - 16'sd64;
                    corrected_vy = -$signed(magnitude(velocity_x) >> 1) - 16'sd24;
                end
            end
        end

        // Position correction plus inward-only reflection prevents sticking
        // and tunnelling at the outer wall or shooter-lane divider.
        if (corrected_y < 16'sd2816) begin
            corrected_y = 16'sd2816;
            if (corrected_vy < 0)
                corrected_vy = $signed((magnitude(corrected_vy) * 7) >> 3);
        end
        if (in_lane) begin
            if (corrected_x < 16'sd22016) begin
                corrected_x = 16'sd22016;
                if (corrected_vx < 0) corrected_vx = -corrected_vx;
            end
            if (corrected_x > 16'sd23552) begin
                corrected_x = 16'sd23552;
                if (corrected_vx > 0) corrected_vx = -corrected_vx;
            end
        end else begin
            if (corrected_x < 16'sd1024) begin
                corrected_x = 16'sd1024;
                if (corrected_vx < 0)
                    corrected_vx = $signed((magnitude(corrected_vx) * 7) >> 3);
            end
            if (corrected_y >= 16'sd4608 && corrected_x > 16'sd20992) begin
                corrected_x = 16'sd20992;
                if (corrected_vx > 0)
                    corrected_vx = -$signed((magnitude(corrected_vx) * 7) >> 3);
            end else if (corrected_x > 16'sd23552) begin
                corrected_x = 16'sd23552;
                if (corrected_vx > 0)
                    corrected_vx = -$signed((magnitude(corrected_vx) * 7) >> 3);
            end
        end
    end
endmodule

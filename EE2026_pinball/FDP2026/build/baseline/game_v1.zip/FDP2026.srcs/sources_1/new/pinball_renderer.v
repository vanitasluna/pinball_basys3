`timescale 1ns / 1ps

// Combinational RGB565 scene generator for the 96 x 64 Pmod OLED.
// A single character ROM and 3 x 5 font are shared by every text region.
// Coordinates and physics use the same table landmarks as pinball_game.
module pinball_renderer (
    input [6:0] x,
    input [5:0] y,
    input [2:0] state,
    input [6:0] ball_x,
    input [5:0] ball_y,
    input [2:0] left_angle,
    input [2:0] right_angle,
    input [15:0] score_bcd,
    input [15:0] high_bcd,
    input [1:0] lives,
    input [1:0] difficulty,
    input [5:0] charge,
    input [4:0] hit_flash,
    input [1:0] bonus_target,
    input bonus_active,
    input [7:0] anim,
    input [6:0] cursor_x,
    input [5:0] cursor_y,
    input cursor_visible,
    input [2:0] combo,
    input [2:0] mission_progress,
    input [1:0] target_progress,
    input [10:0] save_timer,
    input [2:0] feature_event,
    input [9:0] feature_timer,
    input [15:0] last_award_bcd,
    input [55:0] oled_trail_x,
    input [47:0] oled_trail_y,
    input [7:0] trail_valid,
    output reg [15:0] pixel
);
    localparam [2:0] MENU=3'd0, READY=3'd1, PLAY=3'd2,
                     PAUSE=3'd3, OVER=3'd4;
    localparam [15:0] NIGHT=16'h0843, FIELD=16'h08A5, FIELD_LIGHT=16'h10E7,
                      CYAN=16'h07FF, RAIL=16'h05D8, GOLD=16'hFEA0,
                      ORANGE=16'hFD20, PINK=16'hF81F, WHITE=16'hFFFF,
                      MUTED=16'h4A8A, RED=16'hF9A8;

    function [14:0] font_3x5;
        input [7:0] character;
        begin
            case (character)
                "A": font_3x5=15'b010_101_111_101_101;
                "B": font_3x5=15'b110_101_110_101_110;
                "C": font_3x5=15'b011_100_100_100_011;
                "D": font_3x5=15'b110_101_101_101_110;
                "E": font_3x5=15'b111_100_110_100_111;
                "F": font_3x5=15'b111_100_110_100_100;
                "G": font_3x5=15'b011_100_101_101_011;
                "H": font_3x5=15'b101_101_111_101_101;
                "I": font_3x5=15'b111_010_010_010_111;
                "J": font_3x5=15'b001_001_001_101_010;
                "K": font_3x5=15'b101_101_110_101_101;
                "L": font_3x5=15'b100_100_100_100_111;
                "M": font_3x5=15'b101_111_111_101_101;
                "N": font_3x5=15'b101_111_111_111_101;
                "O": font_3x5=15'b010_101_101_101_010;
                "P": font_3x5=15'b110_101_110_100_100;
                "Q": font_3x5=15'b010_101_101_111_011;
                "R": font_3x5=15'b110_101_110_101_101;
                "S": font_3x5=15'b011_100_010_001_110;
                "T": font_3x5=15'b111_010_010_010_010;
                "U": font_3x5=15'b101_101_101_101_111;
                "V": font_3x5=15'b101_101_101_101_010;
                "W": font_3x5=15'b101_101_111_111_101;
                "X": font_3x5=15'b101_101_010_101_101;
                "Y": font_3x5=15'b101_101_010_010_010;
                "Z": font_3x5=15'b111_001_010_100_111;
                "0": font_3x5=15'b111_101_101_101_111;
                "1": font_3x5=15'b010_110_010_010_111;
                "2": font_3x5=15'b110_001_010_100_111;
                "3": font_3x5=15'b110_001_010_001_110;
                "4": font_3x5=15'b101_101_111_001_001;
                "5": font_3x5=15'b111_100_110_001_110;
                "6": font_3x5=15'b011_100_111_101_111;
                "7": font_3x5=15'b111_001_010_010_010;
                "8": font_3x5=15'b111_101_111_101_111;
                "9": font_3x5=15'b111_101_111_001_110;
                ":": font_3x5=15'b000_010_000_010_000;
                "/": font_3x5=15'b001_001_010_100_100;
                "<": font_3x5=15'b001_010_100_010_001;
                ">": font_3x5=15'b100_010_001_010_100;
                "-": font_3x5=15'b000_000_111_000_000;
                "+": font_3x5=15'b000_010_111_010_000;
                default: font_3x5=15'd0;
            endcase
        end
    endfunction

    // One short award message shares the HUD's existing character ROM.
    // Seven padded characters leave room for + and a four-digit award.
    function [7:0] feature_char;
        input [2:0] event_code;
        input [2:0] index;
        reg [55:0] label;
        begin
            case (event_code)
                3'd1: label="BONUS  ";
                3'd2: label="COMBO  ";
                3'd3: label="JACKPOT";
                3'd4: label="SAVED  ";
                3'd5: label="TARGET ";
                3'd6: label="NUDGE  ";
                3'd7: label="TILT   ";
                default: label="       ";
            endcase
            case (index)
                3'd0: feature_char=label[55:48];
                3'd1: feature_char=label[47:40];
                3'd2: feature_char=label[39:32];
                3'd3: feature_char=label[31:24];
                3'd4: feature_char=label[23:16];
                3'd5: feature_char=label[15:8];
                default: feature_char=label[7:0];
            endcase
        end
    endfunction

    function [7:0] message_char;
        input [3:0] message;
        input [4:0] index;
        begin
            case (message)
            4'd0: begin
                case (index)
                    5'd0: message_char = 8'd80;
                    5'd1: message_char = 8'd73;
                    5'd2: message_char = 8'd78;
                    5'd3: message_char = 8'd66;
                    5'd4: message_char = 8'd65;
                    5'd5: message_char = 8'd76;
                    5'd6: message_char = 8'd76;
                    default: message_char = 8'd32;
                endcase
            end
            4'd1: begin
                case (index)
                    5'd0: message_char = 8'd65;
                    5'd1: message_char = 8'd82;
                    5'd2: message_char = 8'd67;
                    5'd3: message_char = 8'd65;
                    5'd4: message_char = 8'd68;
                    5'd5: message_char = 8'd69;
                    default: message_char = 8'd32;
                endcase
            end
            4'd2: begin
                case (index)
                    5'd0: message_char = 8'd60;
                    5'd1: message_char = 8'd32;
                    5'd2: message_char = 8'd69;
                    5'd3: message_char = 8'd65;
                    5'd4: message_char = 8'd83;
                    5'd5: message_char = 8'd89;
                    5'd6: message_char = 8'd32;
                    5'd7: message_char = 8'd62;
                    default: message_char = 8'd32;
                endcase
            end
            4'd3: begin
                case (index)
                    5'd0: message_char = 8'd60;
                    5'd1: message_char = 8'd32;
                    5'd2: message_char = 8'd78;
                    5'd3: message_char = 8'd79;
                    5'd4: message_char = 8'd82;
                    5'd5: message_char = 8'd77;
                    5'd6: message_char = 8'd65;
                    5'd7: message_char = 8'd76;
                    5'd8: message_char = 8'd32;
                    5'd9: message_char = 8'd62;
                    default: message_char = 8'd32;
                endcase
            end
            4'd4: begin
                case (index)
                    5'd0: message_char = 8'd60;
                    5'd1: message_char = 8'd32;
                    5'd2: message_char = 8'd72;
                    5'd3: message_char = 8'd65;
                    5'd4: message_char = 8'd82;
                    5'd5: message_char = 8'd68;
                    5'd6: message_char = 8'd32;
                    5'd7: message_char = 8'd62;
                    default: message_char = 8'd32;
                endcase
            end
            4'd5: begin
                case (index)
                    5'd0: message_char = 8'd67;
                    5'd1: message_char = 8'd58;
                    5'd2: message_char = 8'd32;
                    5'd3: message_char = 8'd83;
                    5'd4: message_char = 8'd84;
                    5'd5: message_char = 8'd65;
                    5'd6: message_char = 8'd82;
                    5'd7: message_char = 8'd84;
                    default: message_char = 8'd32;
                endcase
            end
            4'd6: begin
                case (index)
                    5'd0: message_char = 8'd76;
                    5'd1: message_char = 8'd47;
                    5'd2: message_char = 8'd82;
                    5'd3: message_char = 8'd32;
                    5'd4: message_char = 8'd76;
                    5'd5: message_char = 8'd69;
                    5'd6: message_char = 8'd86;
                    5'd7: message_char = 8'd69;
                    5'd8: message_char = 8'd76;
                    default: message_char = 8'd32;
                endcase
            end
            4'd7: begin
                case (index)
                    5'd0: message_char = 8'd66;
                    5'd1: message_char = 8'd69;
                    5'd2: message_char = 8'd83;
                    5'd3: message_char = 8'd84;
                    5'd4: message_char = 8'd32;
                    default: message_char = 8'd32;
                endcase
            end
            4'd8: begin
                case (index)
                    5'd0: message_char = 8'd72;
                    5'd1: message_char = 8'd79;
                    5'd2: message_char = 8'd76;
                    5'd3: message_char = 8'd68;
                    5'd4: message_char = 8'd32;
                    5'd5: message_char = 8'd67;
                    5'd6: message_char = 8'd58;
                    5'd7: message_char = 8'd32;
                    5'd8: message_char = 8'd67;
                    5'd9: message_char = 8'd72;
                    5'd10: message_char = 8'd65;
                    5'd11: message_char = 8'd82;
                    5'd12: message_char = 8'd71;
                    5'd13: message_char = 8'd69;
                    default: message_char = 8'd32;
                endcase
            end
            4'd9: begin
                case (index)
                    5'd0: message_char = 8'd82;
                    5'd1: message_char = 8'd69;
                    5'd2: message_char = 8'd76;
                    5'd3: message_char = 8'd69;
                    5'd4: message_char = 8'd65;
                    5'd5: message_char = 8'd83;
                    5'd6: message_char = 8'd69;
                    5'd7: message_char = 8'd58;
                    5'd8: message_char = 8'd32;
                    5'd9: message_char = 8'd76;
                    5'd10: message_char = 8'd65;
                    5'd11: message_char = 8'd85;
                    5'd12: message_char = 8'd78;
                    5'd13: message_char = 8'd67;
                    5'd14: message_char = 8'd72;
                    default: message_char = 8'd32;
                endcase
            end
            4'd10: begin
                case (index)
                    5'd0: message_char = 8'd80;
                    5'd1: message_char = 8'd65;
                    5'd2: message_char = 8'd85;
                    5'd3: message_char = 8'd83;
                    5'd4: message_char = 8'd69;
                    5'd5: message_char = 8'd68;
                    default: message_char = 8'd32;
                endcase
            end
            4'd11: begin
                case (index)
                    5'd0: message_char = 8'd85;
                    5'd1: message_char = 8'd58;
                    5'd2: message_char = 8'd32;
                    5'd3: message_char = 8'd82;
                    5'd4: message_char = 8'd69;
                    5'd5: message_char = 8'd83;
                    5'd6: message_char = 8'd85;
                    5'd7: message_char = 8'd77;
                    5'd8: message_char = 8'd69;
                    default: message_char = 8'd32;
                endcase
            end
            4'd12: begin
                case (index)
                    5'd0: message_char = 8'd68;
                    5'd1: message_char = 8'd58;
                    5'd2: message_char = 8'd32;
                    5'd3: message_char = 8'd77;
                    5'd4: message_char = 8'd69;
                    5'd5: message_char = 8'd78;
                    5'd6: message_char = 8'd85;
                    default: message_char = 8'd32;
                endcase
            end
            4'd13: begin
                case (index)
                    5'd0: message_char = 8'd71;
                    5'd1: message_char = 8'd65;
                    5'd2: message_char = 8'd77;
                    5'd3: message_char = 8'd69;
                    5'd4: message_char = 8'd32;
                    5'd5: message_char = 8'd79;
                    5'd6: message_char = 8'd86;
                    5'd7: message_char = 8'd69;
                    5'd8: message_char = 8'd82;
                    default: message_char = 8'd32;
                endcase
            end
            4'd14: begin
                case (index)
                    5'd0: message_char = 8'd83;
                    5'd1: message_char = 8'd67;
                    5'd2: message_char = 8'd79;
                    5'd3: message_char = 8'd82;
                    5'd4: message_char = 8'd69;
                    5'd5: message_char = 8'd32;
                    default: message_char = 8'd32;
                endcase
            end
            4'd15: begin
                case (index)
                    5'd0: message_char = 8'd67;
                    5'd1: message_char = 8'd58;
                    5'd2: message_char = 8'd32;
                    5'd3: message_char = 8'd82;
                    5'd4: message_char = 8'd69;
                    5'd5: message_char = 8'd83;
                    5'd6: message_char = 8'd84;
                    5'd7: message_char = 8'd65;
                    5'd8: message_char = 8'd82;
                    5'd9: message_char = 8'd84;
                    default: message_char = 8'd32;
                endcase
            end
                default: message_char = 8'd32;
            endcase
        end
    endfunction

    function [7:0] bcd_char;
        input [15:0] digits;
        input [1:0] index;
        reg [3:0] digit;
        begin
            case (index)
                2'd0: digit=digits[15:12];
                2'd1: digit=digits[11:8];
                2'd2: digit=digits[7:4];
                default: digit=digits[3:0];
            endcase
            bcd_char = 8'd48 + {4'd0,digit};
        end
    endfunction

    function heart;
        input [2:0] hx;
        input [2:0] hy;
        begin
            case (hy)
                3'd0: heart=(hx==3'd1 || hx==3'd3);
                3'd1,3'd2: heart=(hx<=3'd4);
                3'd3: heart=(hx>=3'd1 && hx<=3'd3);
                3'd4: heart=(hx==3'd2);
                default: heart=1'b0;
            endcase
        end
    endfunction

    wire [6:0] b0dx = x>=7'd26 ? x-7'd26 : 7'd26-x;
    wire [5:0] b0dy = y>=6'd22 ? y-6'd22 : 6'd22-y;
    wire [6:0] b1dx = x>=7'd58 ? x-7'd58 : 7'd58-x;
    wire [5:0] b1dy = y>=6'd22 ? y-6'd22 : 6'd22-y;
    wire [6:0] b2dx = x>=7'd42 ? x-7'd42 : 7'd42-x;
    wire [5:0] b2dy = y>=6'd35 ? y-6'd35 : 6'd35-y;
    wire [7:0] b0sum = {1'b0,b0dx}+{2'b0,b0dy};
    wire [7:0] b1sum = {1'b0,b1dx}+{2'b0,b1dy};
    wire [7:0] b2sum = {1'b0,b2dx}+{2'b0,b2dy};
    wire in_b0 = b0dx<=7'd4 && b0dy<=6'd4 && b0sum<=8'd6;
    wire in_b1 = b1dx<=7'd4 && b1dy<=6'd4 && b1sum<=8'd6;
    wire in_b2 = b2dx<=7'd4 && b2dy<=6'd4 && b2sum<=8'd6;
    wire [6:0] ball_dx = x>=ball_x ? x-ball_x : ball_x-x;
    wire [5:0] ball_dy = y>=ball_y ? y-ball_y : ball_y-y;
    wire [7:0] ball_sum = {1'b0,ball_dx}+{2'b0,ball_dy};
    wire [3:0] ring_radius = 4'd5+{2'd0,anim[3:2]};
    wire [7:0] ring_edge = {4'd0,ring_radius}+8'd2;

    // Distance from each flipper's line, scaled by its 18-pixel length.
    // Small signed products avoid full-width division or trigonometry.
    reg signed [4:0] left_slope, right_slope;
    always @* begin
        case (left_angle)
            3'd0: left_slope=5'sd5;
            3'd1: left_slope=5'sd3;
            3'd2: left_slope=5'sd1;
            3'd3: left_slope=-5'sd2;
            default: left_slope=-5'sd4;
        endcase
        case (right_angle)
            3'd0: right_slope=5'sd5;
            3'd1: right_slope=5'sd3;
            3'd2: right_slope=5'sd1;
            3'd3: right_slope=-5'sd2;
            default: right_slope=-5'sd4;
        endcase
    end
    wire signed [7:0] flipper_y = $signed({2'b00,y})-8'sd53;
    wire signed [7:0] left_dx = $signed({1'b0,x})-8'sd21;
    wire signed [7:0] right_dx = 8'sd65-$signed({1'b0,x});
    wire signed [12:0] left_distance = flipper_y*6'sd18-left_dx*left_slope;
    wire signed [12:0] right_distance = flipper_y*6'sd18-right_dx*right_slope;
    wire [10:0] left_guide_height = {4'd0,x-7'd5}*5'd10;
    wire [10:0] right_guide_height = {4'd0,7'd81-x}*5'd10;
    wire [5:0] left_guide_y = 6'd43+left_guide_height[9:4];
    wire [5:0] right_guide_y = 6'd43+right_guide_height[9:4];

    reg [7:0] glyph;
    reg [2:0] glyph_x, glyph_y;
    reg [4:0] glyph_index;
    reg [15:0] glyph_color;
    reg [14:0] glyph_bits;
    reg bumper_bonus;
    reg bumper_flash;
    reg bumper_mission;
    reg bumper_upper;
    reg [6:0] bumper_dx;
    reg [5:0] bumper_dy;
    reg [7:0] bumper_sum;
    integer trail_index;

    always @* begin
        pixel = NIGHT;
        glyph=8'd32;
        glyph_x=3'd7;
        glyph_y=3'd7;
        glyph_index=5'd0;
        glyph_color=WHITE;
        glyph_bits=15'd0;
        bumper_bonus=1'b0;
        bumper_flash=1'b0;
        bumper_mission=1'b0;
        bumper_upper=1'b0;
        bumper_dx=7'd0;
        bumper_dy=6'd0;
        bumper_sum=8'd0;

        if (state==MENU) begin
            // Moving stars and cabinet lights leave the title and controls clear.
            if ((x==7'd9 && y==6'd15) || (x==7'd84 && y==6'd28) ||
                (x==7'd13 && y==6'd38) || (x==7'd86 && y==6'd47) ||
                (x==7'd77 && y==6'd5) || (x==7'd18 && y==6'd26))
                pixel=anim[5] ? RAIL : MUTED;
            if ((x==7'd10 && y==6'd10+{3'd0,anim[4:2]}) ||
                (x==7'd87 && y==6'd36+{3'd0,anim[5:3]})) pixel=CYAN;
            if (x>=7'd7 && x<=7'd17 && y==6'd53) pixel=ORANGE;
            if (x>=7'd78 && x<=7'd88 && y==6'd53) pixel=ORANGE;
            if ((x==7'd11 && y==6'd49) || (x==7'd84 && y==6'd49))
                pixel=anim[4] ? WHITE : GOLD;
            if (((x==7'd3 || x==7'd92) && y>=6'd3 && y<=6'd60) ||
                (y==6'd3 && x>=7'd3 && x<=7'd92))
                pixel=RAIL;
            if ((y==6'd4 && x>=7'd4 && x<=7'd18) ||
                (y==6'd4 && x>=7'd77 && x<=7'd91))
                pixel=CYAN;
            if (y==6'd29 && x>=7'd26 && x<=7'd69) pixel=MUTED;
            if (y>=6'd31 && y<=6'd39 && x>=7'd22 && x<=7'd73)
                pixel=FIELD_LIGHT;

            if (x>=7'd20 && x<7'd76 && y>=6'd9 && y<6'd19) begin
                glyph_index=(x-7'd20)>>3;
                glyph=message_char(4'd0,glyph_index);
                glyph_x=(x-7'd20)>>1;
                glyph_x=glyph_x & 3'd3;
                glyph_y=(y-6'd9)>>1;
                glyph_color=CYAN;
            end else if (x>=7'd36 && x<7'd60 && y>=6'd23 && y<6'd28) begin
                glyph=message_char(4'd1,(x-7'd36)>>2);
                glyph_x=(x-7'd36)&7'd3;
                glyph_y=y-6'd23;
                glyph_color=PINK;
            end else if (y>=6'd33 && y<6'd38) begin
                if (difficulty==2'd0 && x>=7'd32 && x<7'd64) begin
                    glyph=message_char(4'd2,(x-7'd32)>>2);
                    glyph_x=(x-7'd32)&7'd3;
                    glyph_y=y-6'd33;
                    glyph_color=GOLD;
                end else if (difficulty==2'd1 && x>=7'd28 && x<7'd68) begin
                    glyph=message_char(4'd3,(x-7'd28)>>2);
                    glyph_x=(x-7'd28)&7'd3;
                    glyph_y=y-6'd33;
                    glyph_color=GOLD;
                end else if (difficulty==2'd2 && x>=7'd32 && x<7'd64) begin
                    glyph=message_char(4'd4,(x-7'd32)>>2);
                    glyph_x=(x-7'd32)&7'd3;
                    glyph_y=y-6'd33;
                    glyph_color=GOLD;
                end
            end else if (x>=7'd32 && x<7'd64 && y>=6'd43 && y<6'd48) begin
                glyph=message_char(4'd5,(x-7'd32)>>2);
                glyph_x=(x-7'd32)&7'd3;
                glyph_y=y-6'd43;
                glyph_color=anim[5] ? WHITE : CYAN;
            end else if (x>=7'd30 && x<7'd66 && y>=6'd51 && y<6'd56) begin
                glyph=message_char(4'd6,(x-7'd30)>>2);
                glyph_x=(x-7'd30)&7'd3;
                glyph_y=y-6'd51;
                glyph_color=MUTED;
            end else if (x>=7'd30 && x<7'd66 && y>=6'd58 && y<6'd63) begin
                glyph_index=(x-7'd30)>>2;
                if (glyph_index<5'd5) glyph=message_char(4'd7,glyph_index);
                else glyph=bcd_char(high_bcd,glyph_index-5'd5);
                glyph_x=(x-7'd30)&7'd3;
                glyph_y=y-6'd58;
                glyph_color=GOLD;
            end
        end else begin
            // Main table. The open red drain between the flippers is intentional.
            if (y>=6'd9) pixel=y[4] ? FIELD : FIELD_LIGHT;
            // Motion history is deliberately faint and behind all table objects.
            for (trail_index=0; trail_index<8; trail_index=trail_index+1) begin
                if (state==PLAY && trail_valid[trail_index] && y>=6'd10 &&
                    x==oled_trail_x[trail_index*7 +: 7] &&
                    y==oled_trail_y[trail_index*6 +: 6])
                    pixel=trail_index<2 ? 16'h7BF0 :
                          trail_index<5 ? 16'h34D1 : 16'h21CB;
            end
            if (y==6'd7) pixel=RAIL;
            if ((x==7'd2 || x==7'd94) && y>=6'd9) pixel=CYAN;
            if (y==6'd9 && x>=7'd2 && x<=7'd94) pixel=CYAN;
            if (x==7'd84 && y>=6'd18) pixel=RAIL;
            if (x>=7'd85 && x<=7'd93 && y>=6'd18) pixel=NIGHT;
            if ((x==7'd86 || x==7'd92) && y>=6'd23 && y<=6'd52)
                pixel=FIELD_LIGHT;
            if (y==6'd63 && ((x>=7'd2 && x<=7'd29) ||
                (x>=7'd57 && x<=7'd94))) pixel=RAIL;
            if (y==6'd62 && (x==7'd37 || x==7'd50)) pixel=RED;
            if (save_timer!=11'd0 && y==6'd62 && x>=7'd30 && x<=7'd56)
                pixel=anim[4] ? CYAN : RAIL;
            if ((x>=7'd5 && x<=7'd21 &&
                 (y==left_guide_y || y==left_guide_y+6'd1)) ||
                (x>=7'd65 && x<=7'd81 &&
                 (y==right_guide_y || y==right_guide_y+6'd1))) pixel=CYAN;
            // These sloping lower walls feed the central drain. Their drawn
            // surfaces are two pixels outside the ball-centre collision bounds.
            if (y>=6'd54 && ((y==x+7'd35 || y==x+7'd36) ||
                (x+y==7'd121 || x+y==7'd122))) pixel=RAIL;
            if (x>=7'd86 && x<=7'd92 && y>=6'd56 && y<=6'd61 &&
                (y[0]==1'b0)) pixel=ORANGE;

            // Side targets have a bright outer face and a shaded inner face.
            if (((x>=7'd5 && x<=7'd8) || (x>=7'd77 && x<=7'd80)) &&
                y>=6'd30 && y<=6'd36) begin
                pixel=PINK;
                if ((x==7'd7 || x==7'd78) && y>=6'd31 && y<=6'd35)
                    pixel=((x==7'd7 && hit_flash[3]) ||
                           (x==7'd78 && hit_flash[4])) ? GOLD : 16'h780F;
            end
            if ((x==7'd10 && y>=6'd29 && y<=6'd31) ||
                (x==7'd74 && y>=6'd29 && y<=6'd31))
                pixel=((x==7'd10 && target_progress[0]) ||
                       (x==7'd74 && target_progress[1])) ? GOLD : MUTED;

            // A clipped, expanding diamond is a cheap impact animation.
            if ((hit_flash[0] && b0dx<=ring_radius && b0dy<=ring_radius && b0sum==ring_edge) ||
                (hit_flash[1] && b1dx<=ring_radius && b1dy<=ring_radius && b1sum==ring_edge) ||
                (hit_flash[2] && b2dx<=ring_radius && b2dy<=ring_radius && b2sum==ring_edge))
                pixel=anim[2] ? GOLD : WHITE;

            // Three mission lamps sit immediately above their corresponding bumper.
            if (x>=7'd24 && x<=7'd28 && y>=6'd15 && y<=6'd16)
                pixel=mission_progress[0] ? GOLD : MUTED;
            if (x>=7'd56 && x<=7'd60 && y>=6'd15 && y<=6'd16)
                pixel=mission_progress[1] ? GOLD : MUTED;
            if (x>=7'd40 && x<=7'd44 && y>=6'd28 && y<=6'd29)
                pixel=mission_progress[2] ? GOLD : MUTED;

            if (in_b0 || in_b1 || in_b2) begin
                if (in_b0) begin
                    bumper_dx=b0dx; bumper_dy=b0dy; bumper_sum=b0sum;
                    bumper_bonus=bonus_active && bonus_target==2'd0;
                    bumper_flash=hit_flash[0];
                    bumper_mission=mission_progress[0]; bumper_upper=y<6'd22;
                end else if (in_b1) begin
                    bumper_dx=b1dx; bumper_dy=b1dy; bumper_sum=b1sum;
                    bumper_bonus=bonus_active && bonus_target==2'd1;
                    bumper_flash=hit_flash[1];
                    bumper_mission=mission_progress[1]; bumper_upper=y<6'd22;
                end else begin
                    bumper_dx=b2dx; bumper_dy=b2dy; bumper_sum=b2sum;
                    bumper_bonus=bonus_active && bonus_target==2'd2;
                    bumper_flash=hit_flash[2];
                    bumper_mission=mission_progress[2]; bumper_upper=y<6'd35;
                end
                pixel=bumper_bonus || bumper_mission ? GOLD : CYAN;
                if (bumper_dx<=7'd3 && bumper_dy<=6'd3 && bumper_sum<=8'd4)
                    pixel=bumper_bonus ? 16'h8200 : 16'h0170;
                if (bumper_sum<=8'd2)
                    pixel=bumper_flash ? WHITE :
                        (bumper_bonus && anim[4] ? WHITE : PINK);
                if (bumper_dy==6'd3 && bumper_dx<=7'd1 && bumper_upper) pixel=WHITE;
                if (bumper_mission && bumper_sum<=8'd1) pixel=GOLD;
                if (bumper_bonus && bumper_upper && bumper_dx=={4'd0,anim[4:2]})
                    pixel=WHITE;
            end

            if (x>=7'd21 && x<=7'd39 &&
                left_distance>=-13'sd27 && left_distance<=13'sd27)
                pixel=ORANGE;
            if (x>=7'd47 && x<=7'd65 &&
                right_distance>=-13'sd27 && right_distance<=13'sd27)
                pixel=ORANGE;
            if ((x>=7'd20 && x<=7'd22 && y>=6'd52 && y<=6'd54) ||
                (x>=7'd64 && x<=7'd66 && y>=6'd52 && y<=6'd54))
                pixel=GOLD;
            if ((x==7'd21 || x==7'd65) && y==6'd53) pixel=WHITE;

            if (y>=6'd9 && ball_dx<=7'd2 && ball_dy<=6'd2 &&
                ball_sum<=8'd3) begin
                pixel=WHITE;
                if (y>ball_y) pixel=16'hA514;
                else if (x>ball_x) pixel=16'hD69A;
                if (x<ball_x && y<ball_y) pixel=16'hFFFF;
                if (x==ball_x && y==ball_y) pixel=16'hEF7D;
            end

            // Compact HUD: score, lives (three hearts), and difficulty initial.
            if (x>=7'd3 && x<7'd31 && y>=6'd1 && y<6'd6) begin
                glyph_index=(x-7'd3)>>2;
                if (glyph_index==5'd0) glyph="S";
                else if (glyph_index==5'd1) glyph="C";
                else if (glyph_index==5'd2) glyph=8'd32;
                else glyph=bcd_char(score_bcd,glyph_index-5'd3);
                glyph_x=(x-7'd3)&7'd3; glyph_y=y-6'd1;
            end else if (combo>3'd1 && x>=7'd33 && x<7'd41 && y>=6'd1 && y<6'd6) begin
                glyph=x<7'd37 ? "X" : 8'd48+{5'd0,combo};
                glyph_x=(x-7'd33)&7'd3; glyph_y=y-6'd1;
                glyph_color=combo>=3'd4 ? WHITE : GOLD;
            end else if (x>=7'd43 && x<7'd47 && y>=6'd1 && y<6'd6) begin
                glyph="L"; glyph_x=x-7'd43; glyph_y=y-6'd1;
                glyph_color=RED;
            end else if (save_timer!=11'd0 && x>=7'd74 && x<7'd78 && y>=6'd1 && y<6'd6) begin
                glyph="S"; glyph_x=x-7'd74; glyph_y=y-6'd1;
                glyph_color=save_timer<11'd120 && anim[3] ? RED : CYAN;
            end else if (x>=7'd86 && x<7'd90 && y>=6'd1 && y<6'd6) begin
                glyph=difficulty==2'd0 ? "E" : difficulty==2'd1 ? "N" : "H";
                glyph_x=x-7'd86; glyph_y=y-6'd1;
                glyph_color=GOLD;
            end
            if (x>=7'd51 && x<=7'd55 && y>=6'd1 && y<=6'd5 &&
                heart(x-7'd51,y-6'd1)) pixel=lives>=2'd1 ? RED : MUTED;
            if (x>=7'd58 && x<=7'd62 && y>=6'd1 && y<=6'd5 &&
                heart(x-7'd58,y-6'd1)) pixel=lives>=2'd2 ? RED : MUTED;
            if (x>=7'd65 && x<=7'd69 && y>=6'd1 && y<=6'd5 &&
                heart(x-7'd65,y-6'd1)) pixel=lives>=2'd3 ? RED : MUTED;

            if (state==PLAY && feature_timer!=10'd0 && feature_event!=3'd0 &&
                x>=7'd18 && x<=7'd69 && y>=6'd11 && y<=6'd17) begin
                pixel=NIGHT;
                if (y==6'd11 || y==6'd17) pixel=feature_event==3'd7 ? RED : RAIL;
                if (x>=7'd20 && x<7'd68 && y>=6'd12 && y<6'd17) begin
                    glyph_index=(x-7'd20)>>2;
                    if (glyph_index<5'd7) glyph=feature_char(feature_event,glyph_index[2:0]);
                    else if (feature_event==3'd4 || feature_event>=3'd6) glyph=8'd32;
                    else if (glyph_index==5'd7) glyph="+";
                    else glyph=bcd_char(last_award_bcd,glyph_index-5'd8);
                    glyph_x=(x-7'd20)&7'd3; glyph_y=y-6'd12;
                    glyph_color=feature_event==3'd7 ? RED :
                                feature_event==3'd3 ? GOLD : WHITE;
                end
            end

            if (state==READY) begin
                // Charge meter's 63-pixel interior directly matches charge 0..63.
                if (x>=7'd10 && x<=7'd75 && y>=6'd12 && y<=6'd16) begin
                    pixel=MUTED;
                    if (x>=7'd11 && x<=7'd74 && y>=6'd13 && y<=6'd15)
                        pixel=NIGHT;
                    if (x>=7'd11 && {1'b0,x}<8'd11+{2'b0,charge} &&
                        y>=6'd13 && y<=6'd15) pixel=GOLD;
                end
                if (x>=7'd13 && x<=7'd80 && y>=6'd37 && y<=6'd52)
                    pixel=NIGHT;
                if (x>=7'd20 && x<7'd76 && y>=6'd39 && y<6'd44) begin
                    glyph=message_char(4'd8,(x-7'd20)>>2);
                    glyph_x=(x-7'd20)&7'd3; glyph_y=y-6'd39;
                    glyph_color=GOLD;
                end else if (x>=7'd18 && x<7'd78 && y>=6'd46 && y<6'd51) begin
                    glyph=message_char(4'd9,(x-7'd18)>>2);
                    glyph_x=(x-7'd18)&7'd3; glyph_y=y-6'd46;
                    glyph_color=WHITE;
                end
            end

            if (state==PAUSE || state==OVER) begin
                if (y>=6'd9)
                    pixel={1'b0,pixel[15:12],1'b0,pixel[10:6],1'b0,pixel[4:1]};
                if (x>=7'd8 && x<=7'd83 && y>=6'd17 && y<=6'd55) begin
                    pixel=NIGHT;
                    if (x==7'd8 || x==7'd83 || y==6'd17 || y==6'd55)
                        pixel=state==OVER ? GOLD : RAIL;
                end
                if (state==PAUSE) begin
                    if (x>=7'd24 && x<7'd72 && y>=6'd25 && y<6'd35) begin
                        glyph=message_char(4'd10,(x-7'd24)>>3);
                        glyph_x=((x-7'd24)>>1)&7'd3;
                        glyph_y=(y-6'd25)>>1;
                        glyph_color=CYAN;
                    end else if (x>=7'd30 && x<7'd66 && y>=6'd41 && y<6'd46) begin
                        glyph=message_char(4'd11,(x-7'd30)>>2);
                        glyph_x=(x-7'd30)&7'd3; glyph_y=y-6'd41;
                        glyph_color=WHITE;
                    end else if (x>=7'd34 && x<7'd62 && y>=6'd49 && y<6'd54) begin
                        glyph=message_char(4'd12,(x-7'd34)>>2);
                        glyph_x=(x-7'd34)&7'd3; glyph_y=y-6'd49;
                        glyph_color=MUTED;
                    end
                end else begin
                    if (x>=7'd12 && x<7'd84 && y>=6'd21 && y<6'd31) begin
                        glyph=message_char(4'd13,(x-7'd12)>>3);
                        glyph_x=((x-7'd12)>>1)&7'd3;
                        glyph_y=(y-6'd21)>>1;
                        glyph_color=RED;
                    end else if (x>=7'd28 && x<7'd68 && y>=6'd34 && y<6'd39) begin
                        glyph_index=(x-7'd28)>>2;
                        if (glyph_index<5'd6) glyph=message_char(4'd14,glyph_index);
                        else glyph=bcd_char(score_bcd,glyph_index-5'd6);
                        glyph_x=(x-7'd28)&7'd3; glyph_y=y-6'd34;
                        glyph_color=WHITE;
                    end else if (x>=7'd30 && x<7'd66 && y>=6'd41 && y<6'd46) begin
                        glyph_index=(x-7'd30)>>2;
                        if (glyph_index<5'd5) glyph=message_char(4'd7,glyph_index);
                        else glyph=bcd_char(high_bcd,glyph_index-5'd5);
                        glyph_x=(x-7'd30)&7'd3; glyph_y=y-6'd41;
                        glyph_color=GOLD;
                    end else if (x>=7'd28 && x<7'd68 && y>=6'd49 && y<6'd54) begin
                        glyph=message_char(4'd15,(x-7'd28)>>2);
                        glyph_x=(x-7'd28)&7'd3; glyph_y=y-6'd49;
                        glyph_color=CYAN;
                    end
                end
            end
        end

        glyph_bits=font_3x5(glyph);
        if (glyph_x<3'd3 && glyph_y<3'd5) begin
            if (glyph_bits[4'd14-(glyph_y*2'd3)-glyph_x]) pixel=glyph_color;
        end

        // Optional PS/2 pointer; a tiny outlined cross stays readable on OLED.
        if (cursor_visible) begin
            if (((x>=cursor_x && x<=cursor_x+7'd3) && y==cursor_y) ||
                ((y>=cursor_y && y<=cursor_y+6'd3) && x==cursor_x))
                pixel=GOLD;
            if (x==cursor_x+7'd1 && y==cursor_y+6'd1) pixel=NIGHT;
        end
    end
endmodule


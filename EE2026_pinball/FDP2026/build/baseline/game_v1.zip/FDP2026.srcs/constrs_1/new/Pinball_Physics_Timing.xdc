# Implementation-only constraints: read after synthesis maps registers.
# Physics snapshots are latched on tick, held unchanged, and their collision
# result is committed exactly 16 system-clock edges later. Only these isolated
# calculation paths receive a multicycle exception; controls retain 10 ns timing.
set collision_sources [get_cells -hierarchical -filter {REF_NAME =~ FD* && NAME =~ physics/collision_*_reg* && NAME !~ physics/collision_busy_reg* && NAME !~ physics/collision_wait_reg*}]
set collision_destinations [get_cells -hierarchical -filter {REF_NAME =~ FD* && (NAME =~ physics/position_*_reg* || NAME =~ physics/velocity_*_reg* || NAME =~ physics/hit_events_reg* || NAME =~ physics/hit_armed_reg* || NAME =~ physics/cooldown_reg* || NAME =~ physics/in_lane_reg* || NAME =~ physics/launched_reg* || NAME =~ physics/drained_reg*)}]
set_multicycle_path 16 -setup -from $collision_sources -to $collision_destinations
set_multicycle_path 15 -hold -from $collision_sources -to $collision_destinations

# These outputs have no 100 MHz receiving clock: LEDs/seven-segment are
# human-visible, PMODEN is a power enable, and PS/2 uses an asynchronous
# handshake with microsecond protocol delays in the supplied controller.
# Bound their actual register-to-pin propagation to 100 ns. OLED SPI data
# and VGA remain timed against their synchronous interface clocks below.
set_max_delay 100 -datapath_only -from [get_clocks sys_clk_pin] -to [get_ports {led[*] seg[*] an[*] dp PS2Clk PS2Data JA[7]}]

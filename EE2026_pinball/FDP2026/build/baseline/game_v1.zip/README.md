# EE2026 FPGA Pinball Arcade

Pinball for the Basys 3, targeting **xc7a35tcpg236-1**. The primary display is a **96 x 64 Pmod OLEDrgb on JA**. A simultaneous VGA output mirrors the OLED at six times its resolution. A mouse is optional; every game action is available on the board.

The implementation follows the supplied EE2026 proposal's physics, collision, graphics, and game/input components. The proposal's scheduling and member-responsibility text was treated as background. The user's hardware specification determines the OLED display and FPGA part. The supplied `Oled_Display.v`, `Mouse_Control.vhd` (`MouseCtl`), and its `Ps2Interface.vhd` dependency are preserved byte for byte.

## Play

| Control | Action |
| --- | --- |
| Center (C) | Start/restart; hold to charge a ready ball, release to launch |
| Left / right (L / R) | Corresponding flipper; select difficulty on the menu |
| Up (U) | Pause/resume |
| Down (D) | Return to menu, preserving the high score |
| SW0 | Enable optional mouse controls |
| SW15 | Full system reset, including OLED startup and high score |
| Mouse left / right | Corresponding flipper during play |
| Mouse middle | Hold/release to charge/launch |
| Mouse left on menu | Start; click the left/right half of the difficulty row to change level |
| Mouse left at game over | Restart |

Press C to start, then hold C and release it to launch. Holding C through the start transition charges the first ball immediately. A quick tap launches with a minimum useful charge. Full charge takes approximately 1.05 seconds. There are three balls per game. Each bumper scores 50, either side target scores 100, and a gold bonus bumper adds 250. The bonus changes periodically and is consumed when hit. Score saturates at 9999 and appears on both displays and the four-digit seven-segment display. The best score persists across games until SW15 or power cycling.

LEDs 0-2 show remaining lives; LED3 shows enabled mouse activity; LEDs4-8 show charge; LEDs9-10 show difficulty; LED11 shows an active bonus; LED12 shows the shooter lane; LED13 shows play; LED14 shows pause; LED15 shows game over.

## Connect and program

1. Connect the Pmod OLEDrgb to **JA**, observing the module and board ground/power markings. This design uses the color OLEDrgb, not the monochrome Pmod OLED.
2. Connect the Basys 3 PROG USB port to the PC. Optionally connect a USB HID mouse directly to the board's separate USB-A host port and enable SW0.
3. Open `FDP2026.xpr` in Vivado 2025.2. `My_Top_Module` is the top and the device is `xc7a35tcpg236-1`. All source files and used pins are already registered.
4. Program `build/pinball_basys3.bit` in Hardware Manager when available, or run Generate Bitstream. Allow the OLED startup sequence to finish before expecting a picture.
5. VGA is optional. The mirror uses 640 x 480 timing, 800 x 525 total pixels, at 25 MHz (approximately 59.52 Hz). A VGA-to-HDMI converter must support that input timing. The image is 576 x 384 with centered borders.

| JA signal | Bus bit | FPGA pin |
| --- | --- | --- |
| CS | 0 | J1 |
| SDIN | 1 | L2 |
| Unused, driven low | 2 | J2 |
| SCLK | 3 | G2 |
| D/C | 4 | H1 |
| RESN | 5 | K2 |
| VCCEN | 6 | H2 |
| PMODEN | 7 | G3 |

## Build and verify

From this project directory in PowerShell:

```powershell
& 'D:\2025.2\Vivado\bin\vivado.bat' -mode batch -source scripts/build.tcl -log build/vivado.log -journal build/vivado.jou
& .\scripts\simulate.ps1
python .\scripts\verify_project.py
python .\scripts\render_previews.py
```

Create the `build` directory before choosing log/journal paths there. The batch build does not depend on the original author's desktop path. It reads the mixed Verilog/VHDL sources, synthesizes, applies implementation-only collision constraints after registers are mapped, places, routes, checks setup and hold slack, writes reports and checkpoints, then produces the bitstream. `simulate.ps1` accepts a `-VivadoBin` path if Vivado is installed elsewhere, and `-Tests tb_game` can run an individual bench. All seven benches are also registered in the project's simulation source set; `tb_top` is the default GUI simulation top. Preview generation requires Pillow. The self-checking tests check game rules, input debouncing, ball movement and collisions, VGA timing, complete renderer frames, and top-level OLED/mouse integration. Top-level simulation can accelerate OLED startup delays without changing the protected source; that test does not measure real power sequencing delays.

See `docs/display_preview.png` for pixels produced by the actual RTL renderer, and `docs/VALIDATION.md` for the recorded build results and remaining board checks.

## Architecture and project knowledge

| Module | Responsibility |
| --- | --- |
| `My_Top_Module` | Clocks, power-on reset, mouse setup, optional controls, frame snapshots, display integration |
| `pinball_input` | Two-stage button synchronization, independent 10 ms debounce, single-cycle press events |
| `pinball_game` | Menu/ready/play/pause/over FSM, three lives, charge, BCD score, high score, pseudorandom bonus |
| `pinball_physics` | Fixed-point ball motion, gravity, velocity bounds, launcher lane, animated flippers |
| `pinball_collision` | Table interactions, position corrections, bouncing, hit masks |
| `pinball_renderer` | RGB565 table, sprites, 3 x 5 glyph font, UI, charge bar, flashes and mouse pointer |
| `pinball_vga` | 640 x 480 timing and sixfold OLED mirror |
| `pinball_sevenseg` | Multiplexed active-low BCD score output |
| Protected supplied modules | OLED SPI/power sequencing and bidirectional PS/2 mouse protocol |

The 100 MHz board oscillator drives all game logic. Physics uses a **240 Hz clock enable**, not a new slow game clock. Each accepted update captures every collision operand into an isolated register bank. Those operands stay fixed for exactly **16 system clocks (160 ns)** before the collision result is committed. Scoped setup-16/hold-15 timing exceptions cover only that calculation; wait counters, controls, and all other paths retain their ordinary timing requirements. Reset or preparing a new ball cancels an outstanding calculation. Separate globally buffered divide-by-16 and divide-by-4 clocks drive the OLED and VGA. Related clocks are explicitly constrained. Each display captures the entire scene at its own frame boundary, preventing objects and scores changing partway through a frame. OLED pixels are supplied combinationally to the original driver's falling-edge logic.

Physics is fixed-point arithmetic rather than floating point. The table uses pixels as its spatial unit and includes gravity, acceleration, dissipative wall reflections, energized bumpers, two moving flippers, two side targets, a shooter lane and a central drain. Difficulty adjusts motion. Contacts are corrected before the next update and scoring is rearmed after separation. The simplified collision model avoids division by a changing value, square roots, and trigonometry; it is designed for this small FPGA and display.

The mouse module's real position ports are **12 bits**, despite stale comments about ten bits. The wrapper initializes its bounds to 95/63 and center to 48/32 after reset. The mouse stays on 100 MHz because its supplied PS/2 interface uses cycle counts for protocol delays. Board controls work independently of mouse detection. Normal restart leaves OLED power sequencing running; only full reset restarts the display. Human-visible outputs, the OLED power enable, and asynchronous PS/2 pins have a conservative 100 ns register-to-pin propagation bound rather than an invented 100 MHz receiving clock. The OLED SPI and VGA interfaces keep their clock-based output requirements.

Primary hardware references used during implementation:

- [Digilent Basys 3 reference manual](https://digilent.com/reference/_media/basys3:basys3_rm.pdf): 100 MHz oscillator, Artix-7 device, VGA, board buttons and USB HID to PS/2 translation.
- [Digilent Pmod OLEDrgb reference manual](https://digilent.com/reference/_media/pmod:pmod:pmodoledrgb_rm.pdf): 96 x 64 color display, SPI and power/control pin functions.
- [Digilent Basys 3 master constraints](https://github.com/Digilent/digilent-xdc/blob/master/Basys-3-Master.xdc): package pin assignments and PS/2 pullups.

## Physical demonstration checklist

Compilation and simulation cannot establish OLED wiring, mouse compatibility, converter support, or game feel on the real board. Verify the menu, hold/release launch, each flipper, bumper/target scoring, pause, three drains, restart/high score, and optional mouse. Tune gravity, launch impulse, flipper impulse, and restitution in the new physics/collision files if board testing suggests a change. Keep the supplied OLED and mouse files unchanged.
